<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">


    <body>

        <div class="policy_content">
            <div class="container">
                <p>As a general rule, this website does not collect Personal Information about you when you visit the site. You can generally visit the site without revealing Personal Information, unless you choose to provide such information.</p>


                <div class="inner-block-main-title">
                    Site <span>Visit Data</span>
                </div>
                <p>This website records your visit and logs the following information for statistical purposes your server's address; the name of the top-level domain from which you access the Internet (for example, .gov, .com, .in, etc.); the type of browser you use; the date and time you access the site; the pages you have accessed and the documents downloaded and the previous Internet address from which you linked directly to the site.</p>
                <p> We will not identify users or their browsing activities, except when a law enforcement agency may exercise a warrant to inspect the service provider's logs.</p>


                <div class="inner-block-main-title">
                    <span>Cookies</span>
                </div>
                <p>A cookie is a piece of software code that an internet web site sends to your browser when you access information at that site. This site does not use cookies.</p>


                <div class="inner-block-main-title">
                    Email <span> Management</span>
                </div>
                <p>Your email address will only be recorded if you choose to send a message. It will only be used for the purpose for which you have provided it and will not be added to a mailing list. Your email address will not be used for any other purpose, and will not be disclosed, without your consent.</p>

                <div class="inner-block-main-title">
                    Collection of <span> Personal Information</span>
                </div>
                <p>If you are asked for any other Personal Information you will be informed how it will be used if you choose to give it. If at any time you believe the principles referred to in this privacy statement have not been followed, or have any other comments on these principles, please notify the webmaster through the contact us page.</p>

                <div class="inner-block-title">
                    Note:
                </div>
                <p>The use of the term "Personal Information" in this privacy statement refers to any information from which your identity is apparent or can be reasonably ascertained.</p>


            </div>
        </div>


    </body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>