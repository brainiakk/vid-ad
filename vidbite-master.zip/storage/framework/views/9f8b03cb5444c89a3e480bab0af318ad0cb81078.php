<?php $__env->startSection("content"); ?>



<!DOCTYPE html>
<html lang="en">



<body>
    <div class="container">
        <div class="user_profile">
            <div class="panel mypanel">
                <div class="panel-body">
                    <div class="inner-block-main-title" style="margin-top: 0;">
                        User <span>Profile</span>

                    </div>



                    <div class="form-horizontal" data-backdrop="static">
                        <div id="ContentPlaceHolder1_UpdatePanel2">

                            <div class="form-style-agile">
                                <div class="row">
                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            First Name</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-user" aria-hidden="true"></span>

                                            <input name="ctl00$ContentPlaceHolder1$txtFirstName" type="text" value="RAJAN" maxlength="100" id="ContentPlaceHolder1_txtFirstName" tabindex="4" class="textbox" style="width:165px;">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            Last Name</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-user" aria-hidden="true"></span>

                                            <input name="ctl00$ContentPlaceHolder1$txtLastName" type="text" value="PATEL" maxlength="100" id="ContentPlaceHolder1_txtLastName" tabindex="5" class="textbox" style="width:165px;">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-style-agile">
                                <div class="row">
                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            Mobile Number</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-phone" aria-hidden="true"></span>

                                            <input name="ctl00$ContentPlaceHolder1$txtMobileNo" type="tel" value="7874449936" maxlength="10" id="ContentPlaceHolder1_txtMobileNo" tabindex="8" class="textbox pull-left" style="width:100%;">
                                            <span id="ContentPlaceHolder1_lblMobileNo"></span>

                                        </div>

                                    </div>

                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            Email Id</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-envelope" aria-hidden="true"></span>

                                            <input name="ctl00$ContentPlaceHolder1$txtEmailId" type="text" value="sutariyarajan214@gmail.com" maxlength="100" onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$txtEmailId\',\'\')', 0)" onkeypress="if (WebForm_TextBoxKeyHandler(event) == false) return false;" id="ContentPlaceHolder1_txtEmailId" disabled="disabled" tabindex="9" class="aspNetDisabled textbox" style="width:165px;">

                                        </div>
                                        <span id="ContentPlaceHolder1_Label1" class="message" style="color:Red;"></span>

                                    </div>

                                </div>
                            </div>

                            <div class="form-style-agile">
                                <div class="row">
                                    <div class="col-sm-12 col-xs-12">
                                        <label>
                                            Address</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-map-marker" aria-hidden="true"></span>

                                            <textarea name="ctl00$ContentPlaceHolder1$txtAddress" rows="3" cols="20" id="ContentPlaceHolder1_txtAddress" tabindex="10" class="textbox" style="width:95%;">Sarthana jakatnaka, Surat</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="form-style-agile">
                                <div class="row">
                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            Country</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-map-signs" aria-hidden="true"></span>

                                            <select name="ctl00$ContentPlaceHolder1$drpCountry" onchange="javascript:setTimeout('__doPostBack(\'ctl00$ContentPlaceHolder1$drpCountry\',\'\')', 0)" id="ContentPlaceHolder1_drpCountry" tabindex="11" style="width:100%;">
                                                <option value="0">---Please Select---</option>
                                                <option value="4">Afghanistan</option>
                                                <option value="17">Åland Islands</option>
                                                <option value="7">Albania</option>
                                                <option value="5">Algeria</option>
                                                <option value="11">American Samoa</option>
                                                <option value="9">Andorra</option>
                                                <option value="10">Angola</option>
                                                <option value="16">Anguilla</option>
                                                <option value="18">Antarctica</option>
                                                <option value="2">Antigua and Barbuda</option>
                                                <option value="12">Argentina</option>
                                                <option value="8">Armenia</option>
                                                <option value="1">Aruba</option>
                                                <option value="14">Ashmore and Cartier Islands</option>
                                                <option value="13">Australia</option>
                                                <option value="15">Austria</option>
                                                <option value="6">Azerbaijan</option>
                                                <option value="24">Bahamas, The</option>
                                                <option value="19">Bahrain</option>
                                                <option value="85">Baker Island</option>
                                                <option value="25">Bangladesh</option>
                                                <option value="20">Barbados</option>
                                                <option value="35">Bassas da India</option>
                                                <option value="31">Belarus</option>
                                                <option value="23">Belgium</option>
                                                <option value="26">Belize</option>
                                                <option value="30">Benin</option>
                                                <option value="22">Bermuda</option>
                                                <option value="36">Bhutan</option>
                                                <option value="28">Bolivia</option>
                                                <option value="27">Bosnia and Herzegovina</option>
                                                <option value="21">Botswana</option>
                                                <option value="38">Bouvet Island</option>
                                                <option value="34">Brazil</option>
                                                <option value="116">British Indian Ocean Territory</option>
                                                <option value="255">British Virgin Islands</option>
                                                <option value="39">Brunei</option>
                                                <option value="37">Bulgaria</option>
                                                <option value="250">Burkina Faso</option>
                                                <option value="40">Burundi</option>
                                                <option value="42">Cambodia</option>
                                                <option value="51">Cameroon</option>
                                                <option value="41">Canada</option>
                                                <option value="59">Cape Verde</option>
                                                <option value="49">Cayman Islands</option>
                                                <option value="57">Central African Republic</option>
                                                <option value="43">Chad</option>
                                                <option value="48">Chile</option>
                                                <option value="47">China</option>
                                                <option value="136">Christmas Island</option>
                                                <option value="117">Clipperton Island</option>
                                                <option value="50">Cocos (Keeling) Islands</option>
                                                <option value="53">Colombia</option>
                                                <option value="52">Comoros</option>
                                                <option value="46">Congo, Democratic Republic of the</option>
                                                <option value="45">Congo, Republic of the</option>
                                                <option value="60">Cook Islands</option>
                                                <option value="55">Coral Sea Islands</option>
                                                <option value="56">Costa Rica</option>
                                                <option value="121">Cote d\Ivoire</option>
                                                <option value="110">Croatia</option>
                                                <option value="58">Cuba</option>
                                                <option value="61">Cyprus</option>
                                                <option value="77">Czech Republic</option>
                                                <option value="62">Denmark</option>
                                                <option value="67">Dhekelia Sovereign Base Area</option>
                                                <option value="63">Djibouti</option>
                                                <option value="64">Dominica</option>
                                                <option value="66">Dominican Republic</option>
                                                <option value="240">East Timor</option>
                                                <option value="68">Ecuador</option>
                                                <option value="69">Egypt</option>
                                                <option value="74">El Salvador</option>
                                                <option value="71">Equatorial Guinea</option>
                                                <option value="73">Eritrea</option>
                                                <option value="72">Estonia</option>
                                                <option value="75">Ethiopia</option>
                                                <option value="76">Europa Island</option>
                                                <option value="81">Falkland Islands (Islas Malvinas)</option>
                                                <option value="83">Faroe Islands</option>
                                                <option value="80">Fiji</option>
                                                <option value="79">Finland</option>
                                                <option value="86">France</option>
                                                <option value="78">French Guiana</option>
                                                <option value="84">French Polynesia</option>
                                                <option value="87">French Southern and Antarctic Lands</option>
                                                <option value="89">Gabon</option>
                                                <option value="88">Gambia, The</option>
                                                <option value="104">Gaza Strip</option>
                                                <option value="90">Georgia</option>
                                                <option value="96">Germany</option>
                                                <option value="91">Ghana</option>
                                                <option value="92">Gibraltar</option>
                                                <option value="97">Glorioso Islands</option>
                                                <option value="100">Greece</option>
                                                <option value="95">Greenland</option>
                                                <option value="93">Grenada</option>
                                                <option value="98">Guadeloupe</option>
                                                <option value="99">Guam</option>
                                                <option value="101">Guatemala</option>
                                                <option value="94">Guernsey</option>
                                                <option value="102">Guinea</option>
                                                <option value="199">Guinea-Bissau</option>
                                                <option value="103">Guyana</option>
                                                <option value="105">Haiti</option>
                                                <option value="107">Heard Island and McDonald Islands</option>
                                                <option value="258">Holy See (Vatican City)</option>
                                                <option value="108">Honduras</option>
                                                <option value="106">Hong Kong</option>
                                                <option value="109">Howland Island</option>
                                                <option value="111">Hungary</option>
                                                <option value="112">Iceland</option>
                                                <option selected="selected" value="115">India</option>
                                                <option value="113">Indonesia</option>
                                                <option value="118">Iran</option>
                                                <option value="122">Iraq</option>
                                                <option value="70">Ireland</option>
                                                <option value="114">Isle of Man</option>
                                                <option value="119">Israel</option>
                                                <option value="120">Italy</option>
                                                <option value="125">Jamaica</option>
                                                <option value="126">Jan Mayen</option>
                                                <option value="123">Japan</option>
                                                <option value="65">Jarvis Island</option>
                                                <option value="124">Jersey</option>
                                                <option value="128">Johnston Atoll</option>
                                                <option value="127">Jordan</option>
                                                <option value="129">Juan de Nova Island</option>
                                                <option value="139">Kazakhstan</option>
                                                <option value="130">Kenya</option>
                                                <option value="133">Kingman Reef</option>
                                                <option value="134">Kiribati</option>
                                                <option value="132">Korea, North</option>
                                                <option value="135">Korea, South</option>
                                                <option value="138">Kosovo</option>
                                                <option value="137">Kuwait</option>
                                                <option value="131">Kyrgyzstan</option>
                                                <option value="140">Laos</option>
                                                <option value="142">Latvia</option>
                                                <option value="141">Lebanon</option>
                                                <option value="148">Lesotho</option>
                                                <option value="144">Liberia</option>
                                                <option value="150">Libyan Arab</option>
                                                <option value="147">Liechtenstein</option>
                                                <option value="143">Lithuania</option>
                                                <option value="149">Luxembourg</option>
                                                <option value="153">Macau</option>
                                                <option value="151">Madagascar</option>
                                                <option value="158">Malawi</option>
                                                <option value="171">Malaysia</option>
                                                <option value="169">Maldives</option>
                                                <option value="161">Mali</option>
                                                <option value="167">Malta</option>
                                                <option value="203">Marshall Islands</option>
                                                <option value="152">Martinique</option>
                                                <option value="166">Mauritania</option>
                                                <option value="164">Mauritius</option>
                                                <option value="155">Mayotte</option>
                                                <option value="170">Mexico</option>
                                                <option value="82">Micronesia, Federated States of</option>
                                                <option value="165">Midway Islands</option>
                                                <option value="154">Moldova, Republic of</option>
                                                <option value="162">Monaco</option>
                                                <option value="156">Mongolia</option>
                                                <option value="159">Montenegro</option>
                                                <option value="157">Montserrat</option>
                                                <option value="163">Morocco</option>
                                                <option value="172">Mozambique</option>
                                                <option value="29">Myanmar</option>
                                                <option value="259">Namibia</option>
                                                <option value="183">Nauru</option>
                                                <option value="33">Navassa Island</option>
                                                <option value="182">Nepal</option>
                                                <option value="179">Netherlands</option>
                                                <option value="185">Netherlands Antilles</option>
                                                <option value="173">New Caledonia</option>
                                                <option value="187">New Zealand</option>
                                                <option value="186">Nicaragua</option>
                                                <option value="176">Niger</option>
                                                <option value="178">Nigeria</option>
                                                <option value="174">Niue</option>
                                                <option value="180">No Man\s Land</option>
                                                <option value="175">Norfolk Island</option>
                                                <option value="54">Northern Mariana Islands</option>
                                                <option value="181">Norway</option>
                                                <option value="168">Oman</option>
                                                <option value="193">Pakistan</option>
                                                <option value="198">Palau</option>
                                                <option value="146">Palmyra Atoll</option>
                                                <option value="195">Panama</option>
                                                <option value="197">Papua New Guinea</option>
                                                <option value="191">Paracel Islands</option>
                                                <option value="188">Paraguay</option>
                                                <option value="190">Peru</option>
                                                <option value="206">Philippines</option>
                                                <option value="189">Pitcairn Islands</option>
                                                <option value="194">Poland</option>
                                                <option value="196">Portugal</option>
                                                <option value="207">Puerto Rico</option>
                                                <option value="200">Qatar</option>
                                                <option value="201">Reunion</option>
                                                <option value="205">Romania</option>
                                                <option value="208">Russia</option>
                                                <option value="209">Rwanda</option>
                                                <option value="216">Saint Helena</option>
                                                <option value="212">Saint Kitts and Nevis</option>
                                                <option value="223">Saint Lucia</option>
                                                <option value="204">Saint Martin</option>
                                                <option value="211">Saint Pierre and Miquelon</option>
                                                <option value="253">Saint Vincent and the Grenadines</option>
                                                <option value="264">Samoa</option>
                                                <option value="219">San Marino</option>
                                                <option value="238">Sao Tome and Principe</option>
                                                <option value="210">Saudi Arabia</option>
                                                <option value="215">Senegal</option>
                                                <option value="202">Serbia</option>
                                                <option value="266">Serbia and Montenegro</option>
                                                <option value="213">Seychelles</option>
                                                <option value="218">Sierra Leone</option>
                                                <option value="220">Singapore</option>
                                                <option value="145">Slovakia</option>
                                                <option value="217">Slovenia</option>
                                                <option value="32">Solomon Islands</option>
                                                <option value="221">Somalia</option>
                                                <option value="214">South Africa</option>
                                                <option value="227">South Georgia and the Islands</option>
                                                <option value="222">Spain</option>
                                                <option value="192">Spratly Islands</option>
                                                <option value="44">Sri Lanka</option>
                                                <option value="224">Sudan</option>
                                                <option value="184">Suriname</option>
                                                <option value="225">Svalbard</option>
                                                <option value="265">Swaziland</option>
                                                <option value="226">Sweden</option>
                                                <option value="229">Switzerland</option>
                                                <option value="228">Syrian Arab Republic</option>
                                                <option value="243">Taiwan</option>
                                                <option value="233">Tajikistan</option>
                                                <option value="245">Tanzania, United Republic of</option>
                                                <option value="279">testing</option>
                                                <option value="270">testre</option>
                                                <option value="232">Thailand</option>
                                                <option value="160">The Former Yugoslav Republic of Macedonia</option>
                                                <option value="237">Togo</option>
                                                <option value="235">Tokelau</option>
                                                <option value="236">Tonga</option>
                                                <option value="230">Trinidad and Tobago</option>
                                                <option value="231">Tromelin Island</option>
                                                <option value="239">Tunisia</option>
                                                <option value="241">Turkey</option>
                                                <option value="244">Turkmenistan</option>
                                                <option value="234">Turks and Caicos Islands</option>
                                                <option value="242">Tuvalu</option>
                                                <option value="246">Uganda</option>
                                                <option value="248">Ukraine</option>
                                                <option value="3">United Arab Emirates</option>
                                                <option value="247">United Kingdom</option>
                                                <option value="249">United States</option>
                                                <option value="251">Uruguay</option>
                                                <option value="252">Uzbekistan</option>
                                                <option value="177">Vanuatu</option>
                                                <option value="254">Venezuela</option>
                                                <option value="256">Vietnam</option>
                                                <option value="257">Virgin Islands (US)</option>
                                                <option value="263">Wake Island</option>
                                                <option value="261">Wallis and Futuna</option>
                                                <option value="260">West Bank</option>
                                                <option value="262">Western Sahara</option>
                                                <option value="267">Yemen</option>
                                                <option value="268">Zambia</option>
                                                <option value="269">Zimbabwe</option>

                                            </select>
                                        </div>

                                    </div>
                                    <div id="ContentPlaceHolder1_divState" class="col-sm-6 col-xs-12">
                                        <label>
                                            State</label>
                                        <div class="pom-agile">
                                            <span class="fa fa-map-signs" aria-hidden="true"></span>


                                            <select name="ctl00$ContentPlaceHolder1$drpState" id="ContentPlaceHolder1_drpState" tabindex="12" style="width:100%;">
                                                <option value="0">---Please Select---</option>
                                                <option value="31">Andaman &amp; Nicobar</option>
                                                <option value="27">Andhra Pradesh</option>
                                                <option value="28">Arunachal Pradesh</option>
                                                <option value="1">Assam</option>
                                                <option value="2">Bihar</option>
                                                <option value="4">Chandigarh</option>
                                                <option value="3">Chhattisgarh</option>
                                                <option value="32">Dadra &amp; Nagar Haveli</option>
                                                <option value="33">Daman &amp; Diu</option>
                                                <option value="5">Delhi</option>
                                                <option value="6">Goa</option>
                                                <option selected="selected" value="7">Gujarat</option>
                                                <option value="8">Haryana</option>
                                                <option value="9">Himachal Pradesh</option>
                                                <option value="10">Jammu &amp; Kashmir</option>
                                                <option value="29">Jharkhand</option>
                                                <option value="11">Karnataka</option>
                                                <option value="12">Kerala</option>
                                                <option value="34">Lakshadweep</option>
                                                <option value="13">Madhya Pradesh</option>
                                                <option value="14">Maharashtra</option>
                                                <option value="15">Manipur</option>
                                                <option value="16">Meghalaya</option>
                                                <option value="17">Mizoram</option>
                                                <option value="18">Nagaland</option>
                                                <option value="19">Orissa</option>
                                                <option value="35">Pondicherry</option>
                                                <option value="20">Punjab</option>
                                                <option value="21">Rajasthan</option>
                                                <option value="22">Sikkim</option>
                                                <option value="23">Tamil Nadu</option>
                                                <option value="24">Tripura</option>
                                                <option value="25">Uttar Pradesh</option>
                                                <option value="30">Uttaranchal</option>
                                                <option value="26">West Bengal</option>

                                            </select>



                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-style-agile">
                                <div class="row">
                                    <div class="col-sm-6 col-xs-12">
                                        <label>
                                            City</label>

                                        <div class="pom-agile">
                                            <span class="fa fa-map-signs" aria-hidden="true"></span>

                                            <input name="ctl00$ContentPlaceHolder1$txtCity" type="text" value="surat" maxlength="50" id="ContentPlaceHolder1_txtCity" tabindex="13" class="textbox" style="width:165px;">
                                        </div>




                                    </div>

                                </div>

                            </div>
                            <div class="form-style-agile">
                                <div class="row">


                                    <div class="col-sm-6 col-xs-12">
                                        <div class="sub-main-w3" style="padding-top: 18px;">
                                            <input type="submit" name="ctl00$ContentPlaceHolder1$btnRegister" value="Update" id="ContentPlaceHolder1_btnRegister" tabindex="14" class="button_login" style="width:100px;"><br>

                                            <span id="ContentPlaceHolder1_reExistEmail" style="color:Red;display:none;">EmailID is already Exist. <br></span>
                                            <span id="ContentPlaceHolder1_reqTxtFirstName" style="color:Red;display:none;">Please Enter First Name<br></span>
                                            <span id="ContentPlaceHolder1_reqTxtLastName" class="message" style="color:Red;display:none;">Please Enter Last Name<br></span>
                                            <span id="ContentPlaceHolder1_reqTxtPassword" class="message" style="color:Red;display:none;">Please Enter Password<br></span>

                                            <span id="ContentPlaceHolder1_reqTxtMobileNo" class="message" style="color:Red;display:none;">Please Enter Mobile No<br></span>
                                            <span id="ContentPlaceHolder1_reqTxtEmailId" class="message" style="color:Red;display:none;">Please Enter EmailId<br></span>

                                            <span id="ContentPlaceHolder1_ReqdrpState" class="message" style="color:Red;display:none;"><br>Please Select State</span>
                                            <span id="ContentPlaceHolder1_reqTxtCity" class="message" style="color:Red;display:none;">Please Enter City<br></span>
                                            <span id="ContentPlaceHolder1_cmpPassword" class="message" style="color:Red;display:none;">Password and Confirm password do not match<br></span>
                                            <span id="ContentPlaceHolder1_regTxtFirstName" class="message" style="color:Red;display:none;">Only alphabets are allowed in First Name<br></span>
                                            <span id="ContentPlaceHolder1_regTxtLastName" class="message" style="color:Red;display:none;">Only alphabets are allowed in Last Name<br></span>
                                            <span id="ContentPlaceHolder1_regTxtPassword" class="message" style="color:Red;display:none;">Only @ # $ % ^ &amp; are allowed in Password<br></span>
                                            <span id="ContentPlaceHolder1_regTxtConfirmPassword" class="message" style="color:Red;display:none;">Only @ # $ % ^ &amp; are allowed in Confirm Password<br></span>
                                            <span id="ContentPlaceHolder1_regMobileNo" class="message" style="color:Red;display:none;">Please Enter 10 digit for mobile<br></span>
                                            <span id="ContentPlaceHolder1_revtxtEmailId" class="message" style="color:Red;display:none;">Please Enter valid email id<br></span>
                                            <span id="ContentPlaceHolder1_regAddress" class="message" style="color:Red;display:none;">Only , / &amp; are allowed in Address other than alphabets<br></span>
                                            <span id="ContentPlaceHolder1_regTxtCity" class="message" style="color:Red;display:none;">Only alphabets are allowed in City<br></span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="ctl00$ContentPlaceHolder1$hfOTP" id="ContentPlaceHolder1_hfOTP">
                            <input type="hidden" name="ctl00$ContentPlaceHolder1$hfExpiry" id="ContentPlaceHolder1_hfExpiry">
                            <input type="hidden" name="ctl00$ContentPlaceHolder1$hfPassword" id="ContentPlaceHolder1_hfPassword">
                            <input type="hidden" name="ctl00$ContentPlaceHolder1$hfCfPassword" id="ContentPlaceHolder1_hfCfPassword">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>