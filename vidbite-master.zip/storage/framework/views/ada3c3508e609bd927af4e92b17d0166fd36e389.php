
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css">
<!-- <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/fontawesome.css" integrity="sha384-eHoocPgXsiuZh+Yy6+7DsKAerLXyJmu2Hadh4QYyt+8v86geixVYwFqUvMU8X90l" crossorigin="anonymous"/> -->
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link href="<?php echo e(asset('css/appp.css')); ?>" rel="stylesheet" type="text/css" >
<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->

<!-- Latest compiled JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>



<nav class=" navbar navbar-expand-lg navbar-light bg-light">
    <div class="nav_header">
        <div class="container-fluid">
            <div class="row navbar">
                <div class="col-lg-2 col-md-3 col-sm-2 logo navbar-brand">
                    <img src="<?php echo e(asset('/image/SasanGirlogo.png')); ?>" alt="Logo Header">
                </div>
                <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button> -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="col-lg-9 col-md-9 col-sm-9 menu collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="list-menu navbar-nav">
                        <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link ms-4">Home</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('aboutus')); ?>" class="nav-link">Abouts Us</a></li>
                        <div class="dropdown">
                            <button class="dropbtn">Booking<i class="fa fa-chevron-down" aria-hidden="true"></i></button>
                            <div class="dropdown-content">
                                <a href="<?php echo e(route('GirJungleSafari')); ?>" class="nav-link">Gir Jungle Safari</a>
                                <a href="<?php echo e(route('DevaliyaBusSafari')); ?>" class="nav-link">Devalia Park Bus Safari</a>
                                <a href="<?php echo e(route('DevaliyaGpsy')); ?>" class="nav-link">Devalia Park Gypsy Safari</a>
                            </div>
                        </div>
                        <li class="nav-item"><a href="<?php echo e(route('Services')); ?>">Services</a></li>
                        <div class="dropdown">
                            <div class="dropbtn-2">Gallery<i class="fa fa-chevron-down" aria-hidden="true"></i></div>
                            <div class="dropdown-content">
                                <a href="<?php echo e(route('galleryphoto')); ?>" class="nav-link">Photo</a>
                                <a href="<?php echo e(route('galleryvideo')); ?>" class="nav-link">Video</a>
                            </div>
                        </div>
                        <!-- <li class="nav-item"><a href="<?php echo e(route('NewsDownload')); ?>" class="nav-link">News & Download</a></li> -->
                        <li class="nav-item"><a href="<?php echo e(route('DoDont')); ?>" class="nav-link">DO's & DON'Ts</a></li>
                        <li class="nav-item"><a href="<?php echo e(route('contactus')); ?>" class="nav-link">Contact Us</a></li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item"><a href="<?php echo e(route('log')); ?>" class="nav-link">Login</a></li> 
                        <?php else: ?> 
                        <li class="nav-item">
                            <div class="dropdown">
                               <i class="fa fa-user-circle-o fa-7x" data-toggle="dropdown" aria-hidden="true" style="font-size: 15px;color:black; text-decoration:none; cursor: pointer;">Welcome,<?php echo e(Auth::user()->first_name); ?></i>
                                <ul class="dropdown-menu">
                                    <li class="nav-item"><a class="nav-link" href="#">Booking History</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#">Profile</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('redirectpass')); ?>">Change Password</a></li>
                                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route ('userprofile')); ?>">Profile</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#">Change Password</a></li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>  


     