<?php $__env->startSection("content"); ?>

<section class="container about_section">
        <div class="row bb">
            <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12 col-12 about_left">
                <img src="<?php echo e(asset('/image/5.jpg')); ?>" alt="About Img"  width="900" height="800">
                <div class="opacity"></div>
            </div>
            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12 about_right">
                <div class="a_title">
                    <div class="abou">About <span>Us</span></div>
                </div>
                <!-- <h1><span>About</span> Us</h1> -->
                <p><span class="or_co">W</span>e at gir national park safari will insure that you can experence gir in best posible way.
                    We Know What Kind Of Jungle Experience You Will Need On Your Visit To The Gir National Park. 
                    Hence, We Endeavor To Use Our In-Depth Knowledge And Understanding Of The Forest For Proffering 
                    You The Best Of Your Time And Money For The Gir National Park Tour. Our Experienced Guides 
                    Navigate You Towards Fulfilling Your Wildlife Fantasies In Our Gir Wild Life Tour Package By 
                    Bestowing You With A Lifetime Experience In ,Gir National Park, The Only Dwelling Of Renowned 
                    Asiatic Lions; Hence, Will Always Remain At The Center Of Tourist Attraction. But, Along With 
                    The Opportunity Of Locating These Regal Beasts At Their Habitat, Our Tailor-Made Gir Wildlife 
                    Tour Package Brings You Scopes To Detect Many Other Elusive Animals And Hard-To-Find Bird Species. 
                    You Can Locate leopards, hynas , jackels and many different species of antylops like four horn deer, 
                    spotted deer and blue bull And Birds Like Brown Fish Owl, Woodpecker, indian pitta ,paradice fly 
                    catcher And Many Others. Our costomized Gir Wildlife Tour Package Brings You Scopes To Detect Many 
                    Other Elusive Animals And Hard-To-Find Bird Species.  Our Proficient Tour Planners Ensure That Our 
                    Clients Get The Highest Level Of Convenience, Comfort, And Luxury During The Tour. And We Are Pleased 
                    To Inform You That All These Will Be Enveloped Within Very Competitive Rates.</p>
            </div>
        </div>
        <div class="details about_data">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 address mt-5">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-road"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">By Road</h4>
                            <span>Gir forest is approachable by road from Junagadh-Mendarda-Talala and Junagadh-Visavadar state highways from Junagadh; Veraval-Talala-Sasan state highway from Veraval; Amreli-Dhari-Kodinar state highway from Amreli, Una-Tulsishyam Dhari and Una Jamwala state highways from Una.</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 phone mt-5">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-train"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">By Rail</h4>
                            <span>The western railway's station is located at Sasan, approximately 60 km away from Junagadh and 45 km away from Veraval. Veraval is well connected to Ahmedabad by a broad-gauge railway line via Junagadh and Rajkot. Taxi and bus services for Sasan-Gir are readily available from both Junagadh and Veraval train stations.</span>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 email mt-5">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-plane"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">By Air</h4>
                            <span>If you are travelling from outside Gujarat, there are also multiple options available for air travel. Keshod is the closest airport (60 km), another nearest airport is Diu (100 km) from Sasan. The other two big and better-connected airports are Rajkot (160 km) and Ahmedabad (370).</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>