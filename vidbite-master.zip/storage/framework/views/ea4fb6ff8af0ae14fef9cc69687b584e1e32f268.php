<?php $__env->startSection('content'); ?>





















































































<div class="col-md-12 contents">
    <div class="row justify-content-center">
        <div class="col-md-6 bg-light border rounded py-3 ">
            <div class="mb-4 text-center">
                <!-- <div class="text-center">
                <img class="logo" src="assets/images/logo.png">

            </div> -->
                <h3>Sign In</h3>
                <p class="mb-4">Sign in to your account</p>
            </div>
            <form action="<?php echo e(url('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="form-group first mb-3">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="form-group last mb-4">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>
                <div class="d-flex mb-5 align-items-center">
                    <span class="mr-auto"><a href="<?php echo e(route('register')); ?>" class="forgot-pass" style="color:#159AFF;">Create new account</a></span>
                    <!-- <span class="ml-auto"><a href="#" class="forgot-pass" style="color:#159AFF;">Forgot Password</a></span> -->
                </div>

                <div class="row">


                    <div class="col s5 offset-md-1 right-align">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="form-check-label" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>
                    </div>

                    <div class="col s5 offset-md-1 left-align">


                        <?php if(Route::has('password.request')): ?>
                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot Your Password?')); ?>

                            </a>
                        <?php endif; ?>
                    </div>

                </div>

                <input type="submit" value="Log In" class="btn btn-block btn-primary py-3" style="background:#159AFF;border-color: #159AFF;">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/auth/login.blade.php ENDPATH**/ ?>