<?php $__env->startSection("content"); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
<div class="container">
	<div class="row">
        <section class="booking">
			<div class="container">
				<div class="booking_back_img">
					<img src="<?php echo e(asset('/image/background_image.png')); ?>" alt="booking Image">
					<div class="booking_form">
						<h2 class="title text-center">Booking For Devaliya Bus Safari</h2>
						<form method="post" action="<?php echo e(route('Devaliyabusonline')); ?>" >
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="type" value="2">
							<div class="mb-3">
								<label >Visit Date :</label><br>
								<input type="date" id="visit" name="visit">
							</div>
							<div class="mb-3">
								<label class="form-label">Timing :</label>
								<select class="form-select" name="time" require>
									<option>--Please Select--</option>
									<option value="7:30 am to 8:00 am">7:30 am to 8:00 am</option>
									<option value="8:00 am to 8:30 am">8:00 am to 8:30 am</option>
									<option value="8:30 am to 9:00 am">8:30 am to 9:00 am</option>
									<option value="9:00 am to 9:30 am">9:00 am to 9:30 am</option>
									<option value="9:30 am to 10:00 am">9:30 am to 10:00 am</option>
									<option value="10:00 am to 10:30 am">10:00 am to 10:30 am</option>
									<option value="10:30 am to 11:00 am">10:30 am to 11:00 am</option>
									<option value="3:00 pm to 3:30 pm">3:00 pm to 3:30 pm</option>
									<option value="3:30 pm to 4:00 pm">3:30 pm to 4:00 pm</option>
									<option value="4:00 pm to 4:30 pm">4:00 pm to 4:30 pm</option>
									<option value="4:30 pm to 5:00 pm">4:30 pm to 5:00 pm</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Indian :</label>
								<input type="text" class="form-control" id="indian" name="indian">
							</div>
							<div class="mb-3">
								<label class="form-label">Foreigner  :</label>
								<input type="text" class="form-control" id="foreigner" name="foreigner">
							</div>
							<button type="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>