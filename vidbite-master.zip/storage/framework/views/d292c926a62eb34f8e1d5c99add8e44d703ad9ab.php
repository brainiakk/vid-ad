<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">


<body>

    <div class="faq_content">
        <div class="container">

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.1 :</span>
                    E-Permit not issued due to Failed Transaction/Server Error
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    If your financial transaction were successful, but an e-permit could not be issued due to server error, then a refund would be processed within 15-20 business days.
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.2 :</span>
                    Problem with the printing of e-permit?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    In this scenario, kindly check the “blocked pop-up” option on your browser. One must allow a “pop-up” in the browser to get a print out from the registered account. If you have paid and the e-print of the permit doesn’t generate, then go to your booking history (from your registered account) on the Gujarat State Lion Conservation Society (GSLCS) website ( <a href="https://girlion.gujarat.gov.in/Index.aspx">https://girlion.gujarat.gov.in/Index.aspx</a> ) and from there, you can re-download/print the e-permit.
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.3 :</span>
                    Unable to click on the pay now/payment option?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    All the particulars of the visitor must be filled/checked in the detail form. The problem may also occur if there is high traffic on the website at that time of payment, so either wait for some time or try again after some time.
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.4 :</span>
                    Refund against cancellation of e-permits?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Refund rules against cancellation For Gir Jungle Safari</b><br>
                    1) Before 10 days - 75% <b>1) Before 5 days - 50% 1) Before 2 days - 25% 1) Less than 2 days - Nil Refund rules against cancellation For Devaliya Safari Park</b><br>
                    <b>There will be “NO REFUND” for cancellation of E-permit for Devalia safari park.</b><br>
                    <b>*No further changes will be applicable on already generated E-permits.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.5 :</span>
                    How many days in advance e-permits can be booked?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    e-Permit can be booked a maximum of 3 months in advance and at least two hours before the visit of Gir Jungle Safari/Devalia Safari Park in a particular time slot if the e-permits are available.
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.6 :</span>
                    Any applicable changes in e-permit charges?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                   <b>Different weekend (Saturday – Sunday) and Festival day rates will be applicable for Gir Jungle Safari/Devalia Safari Park. PDF: </b><a href="https://girlion.gujarat.gov.in/asset/gir-terms.pdf">https://girlion.gujarat.gov.in/asset/gir-terms.pdf</a>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.7 :</span>
                     Calendar function/date selection is not working?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Due to slow internet connectivity or high server load, you may face this problem. Make sure you have good internet connectivity while generating the e-permit.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.8 :</span>
                    Password not retrieved?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                   <b> Due to high traffic on the website, the user may face this problem. The process might take some time. If unsuccessful, the user can try registering with a new email id.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.9 :</span>
                    Can travel companies register with GSCLS?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>No, GSLCS Jungle Safari and Devalia Safari e-permit booking are only for eco-tourists and not for professional tour operators. Bulk booking from a single point is not allowed.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.10 :</span>
                    What are the locally available facilities?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Guide Fee<br>
                       Guide will be mandatory for Gir forest visit and those are available locally at Reception center, Sasan-Gir.<br>
                       Camera Fee<br>
                       Information (Camera charges) is locally available at reception center Sasan-Gir (If applicable)<br>
                       Vehicle Fee<br>
                       Vehicle (Gypsy) is locally available at reception center Sasan-Gir.<br>
                       *An E-permit doesn’t include charges of locally available facilities mentioned above.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.11 :</span>
                    Forest route and other information?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Route and other information related to Gir Jungle Safari visit are provided at the time of reporting at the reception centre, Sasan-Gir.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.12 :</span>
                   Is online booking of Guest House possible?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b> No, guesthouse booking is not available on this particular website. Information on availability is provided locally at the time of arrival at Sinh Sadan, Sasan-Gir, Gujarat.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.13 :</span>
                    Queries related to e-permit or timings
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Queries related to e-permits can be asked by phone/email from every Monday to Saturday between 10:30 am to 6:00 pm (IST).<br>
                    *Please note that the web site is functional 24x7 day throughout the year.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.14 :</span>
                    SMS Service?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>Now all the e-permits confirmations are automatically provided by GSLCS via SMS on the registered and verified mobile number of the visitor.</b>
                </div>
            </div>

            <div class="faq-list">
                <div class="faq-title">
                    <span>Q.15 :</span>
                    Preferred browser for e-permit?
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    <b>This website is best compatible with Google Chrome, Mozilla Firefox, Internet Explorer and Safari. The user might face problem with other browsers.</b>
                </div>
            </div>


        </div>
    </div>


</body>

</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>