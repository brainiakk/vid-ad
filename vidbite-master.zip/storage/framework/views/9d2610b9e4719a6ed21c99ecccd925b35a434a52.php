<?php $__env->startSection("content"); ?>


<!DOCTYPE html>
<html lang="en">



<body>

    <div class="link_content">
        <div class="container">

            <i class="fas fa-angle-double-right"></i>
            <a href="<?php echo e(route('linkcontent')); ?>" class="h2">Things to look for in Jungle</a>

            <div class="inner-block-main-title">
                Government <span>Portal</span>
            </div>

            <div class="row">

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/gswan.png')); ?>" alt="">
                    </a>
                </div>

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/india-gov.png')); ?>" alt="">
                    </a>
                </div>

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/tourisum.png')); ?>" alt="">
                    </a>
                </div>

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/forest.png')); ?>" alt="">
                    </a>
                </div>

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/gujarat-portal.png')); ?>" alt="">
                    </a>
                </div>

                <div class="col-md-2">
                    <a href="" class="imp-links">
                        <img src="<?php echo e(asset('/image/ef-india.png')); ?>" alt="">
                    </a>
                </div>
                
            </div>
        </div>
    </div>







</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>