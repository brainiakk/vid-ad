<?php $__env->startSection("content"); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
<div class="container">
	<div class="row">
        <section class="booking">
			<div class="container">
				<div class="booking_back_img">
					<img src="<?php echo e(asset('/image/background_image.png')); ?>" alt="booking Image">
					<div class="booking_form">
						<h2 class="title text-center">Booking For Devaliya Gpsy</h2>
						<form method="POST" action="<?php echo e(route('DevaliyaGpsyonline')); ?>" >
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="type" value="3">
							<div class="mb-3">
								<label >Visit Date :</label><br>
								<input type="date" id="visit" name="visit">
							</div>
							<div class="mb-3">
								<label class="form-label">Timing :</label>
								<select class="form-select" name="time" require>
									<option>--Please Select--</option>
									<option value="6 am to 9 am">7 AM to 7:55 AM</option>
                                    <option value="6 am to 9 am">8 AM to 8:55 AM</option>
                                    <option value="6 am to 9 am">9 AM to 9:55 AM</option>
                                    <option value="6 am to 9 am">10 AM to 10:55 AM</option>
                                    <option value="6 am to 9 am">3 PM to 3:55 PM</option>
                                    <option value="6 am to 9 am">4 PM to 4:55 PM</option>
                                    <option value="6 am to 9 am">5 PM to 5:55 PM</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Number of Adult:</label>
								<select class="form-select" name="adult" require>
									<option>--Please Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label" >Number of Child :</label>
								<select class="form-select" name="child" require>
									<option>--Please Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
								</select>
							</div>
							<button type="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>