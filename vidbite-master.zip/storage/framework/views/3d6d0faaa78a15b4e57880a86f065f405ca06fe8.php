<?php $__env->startSection("content"); ?>
<section class="gallery_photo">
        <div class="gallery_slider">
            <div class="slider_background">
                <img src="<?php echo e(asset('/image/gallery_slider.png')); ?>" alt="gallery img">
            </div>
            <div class="gallery_title">
                <h3>Contact Us</h3>
            </div>
        </div>
    </section>
    <section class="container contact">
        <div class="timing">
            <div class="main-title">
                Contact <span class="te_br">Timings</span>
            </div>
            <label>Telephonic queries will be respond during 10:30am to 6:00pm (IST) (Monday-Saturday). Email queries will be respond within 48 Hours.</label>
        </div>
        <div class="details sasan_gir">
            <div class="main-title">
                Sasan <span class="or_co">Gir</span> ( Gir Jungle Safari / Develia Gypsy Safari / Develia Bus Safari )
            </div>
            <div class="row">
                <div class="col-sm-4 col-xs-6 address">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-map-marker "></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">Address</h4>
                            <strong>Deputy Conservator of Forests, Wildlife Division,</strong><br>
                            <span>Sasan Gir, Junagadh-Gujarat (India).</span>
                            <a href="https://www.google.com/maps/dir//21.170602,70.5963974/@21.169282,70.597024,16z?hl=en-US" target="_blank" class="btn btn-primary"><i class="fa fa-map-marker"> Click to Go </i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 phone">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">PHONE</h4>
                            <span>02877-285621</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 email">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-envelope-open"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">E-MAIL</h4>
                            <span><a href="#">gslcsgir@yahoo.com</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="details ambardi_safari">
            <div class="main-title">
                Ambardi <span class="or_co">Safari Park</span>
            </div>
            <div class="row">
                <div class="col-sm-4 col-xs-6 address">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-map-marker "></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">Address</h4>
                            <strong>Deputy Conservator of Forests, Wildlife Division,</strong><br>
                            <span>Near Kodiyar Dam, Dhari, District Amreli, Gujarat (India).</span><br>
                            <a href="https://www.google.com/maps?ll=21.33166,71.040898&amp;z=7&amp;t=m&amp;hl=en&amp;gl=IN&amp;mapclient=embed&amp;daddr=Deputy+Conservator+Of+Forests+Gir+East+Division,Vekariya+Para-Dhari+Amreli,+Gujarat+365630@21.3316598,71.0408982" target="_blank" class="btn btn-primary"><i class="fa fa-map-marker"> Click to Go </i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 phone">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">PHONE</h4>
                            <span>9016769612, 6359950214</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 email">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-envelope-open"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">E-MAIL</h4>
                            <span><a href="#">dcf_dhari@yahoo.com</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="details nature_safari">
            <div class="main-title">
                Girnar <span class="or_co">Nature Safari</span>
            </div>
            <div class="row">
                <div class="col-sm-4 col-xs-6 address">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-map-marker "></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">Address</h4>
                            <strong>Girnar Nature Safari, Indreshwar Thana, Dolatpara,Junagadh</strong><br>
                            <span>Gujarat (India) - 362004.</span><br>
                            <a href="https://www.google.co.in/maps/place/GIRNAR+NATURE+SAFARI/@21.5533785,70.4724203,17z/data=!3m1!4b1!4m5!3m4!1s0x395803693d75df87:0x55ec2562899bd5ca!8m2!3d21.5533735!4d70.474609" target="_blank" class="btn btn-primary"><i class="fa fa-map-marker"> Click to Go</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 phone">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">PHONE</h4>
                            <span>0285-2631182</span>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-6 email">
                    <div class="row">
                        <div class="col-sm-2 col-xs-2 icon">
                            <i class="fa fa-envelope-open"></i>
                        </div>
                        <div class="col-sm-10 col-xs-10 data">
                            <h4 class="or_co">E-MAIL</h4>
                            <span><a href="#">girnar.safari@gmail.com</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>