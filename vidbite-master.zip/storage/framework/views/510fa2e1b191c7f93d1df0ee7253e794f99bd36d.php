<?php $__env->startSection("content"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <section class="container regs reg_sec shadow p-3 mb-5 bg-white rounded">
            <div class="b_content">
                <div class="container">
                    <div class="modal-header">
                        <div class="title pull-left">
                            User Login / Registration
                        </div>
                        <ul class="nav nav-pills login inline-block pull-right bttn">
                            <li class=""><a href="<?php echo e(route('log')); ?>">Already User ? Login</a></li>
                        </ul>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('InsertRegister')); ?>"  method="post" class="form form-horizontal" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        First Name</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-user" aria-hidden="true"></span>
                                        <input name="first_name" type="text" maxlength="100" tabindex="4" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Last Name</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-user" aria-hidden="true"></span>
                                        <input name="last_name" type="text" maxlength="100" tabindex="5" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Password</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-key" aria-hidden="true"></span>
                                        <input name="password" type="text" maxlength="100" tabindex="4" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Confirm Password</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-key" aria-hidden="true"></span>
                                        <input name="new_password_confirmation" type="text" maxlength="100" tabindex="5" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Mobile Number</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-phone" aria-hidden="true"></span>
                                        <input name="mobile" type="tel" maxlength="10" tabindex="8" class="textbox pull-left" style="width:100%;">
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Email Id</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-envelope" aria-hidden="true"></span>
                                        <input name="email" type="text" maxlength="100" tabindex="5" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <label>
                                        Address</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-map-marker" aria-hidden="true"></span>
                                        <textarea name="address" rows="3" cols="20" id="ucHeader_ucUserRegistration_txtAddress" tabindex="10" class="textbox" style="width:95%;"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        Country</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-map-signs" aria-hidden="true"></span>
                                        <select name="country" tabindex="11" style="width:100%;">
                                            <option selected="selected" value="0">---Please Select---</option>
                                            <option>India</option>
                                            <option>Åland Islands</option>
                                            <option>Albania</option>
                                            <option>Algeria</option>
                                            <option>American Samoa</option>
                                            <option>Andorra</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        State</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-envelope" aria-hidden="true"></span>
                                        <select name="state" tabindex="11" style="width:100%;">
                                                <option>Gujarat</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-style-agile">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <label>
                                        City</label>
                                    <div class="pom-agile">
                                        <span class="fa fa-map-signs" aria-hidden="true"></span>
                                        <input name="city" type="text" maxlength="50" tabindex="13" class="textbox" style="width:165px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="sub-main-w3">
                            <button class="b_btn">Register</button>
                        </div>
                        </form>
                </div>
                </div>
            </div>
        </section>
    </div>
</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>