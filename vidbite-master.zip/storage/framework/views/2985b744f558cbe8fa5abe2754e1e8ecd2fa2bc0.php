<?php $__env->startSection("content"); ?>



<section class="gallery_photo download">
        <div class="gallery_slider">
            <div class="slider_background">
                <img src="<?php echo e(asset('/image/gallery_slider.png')); ?>" alt="gallery img">
            </div>
            <div class="gallery_title">
                <h3>Representative Images</h3>
            </div>
        </div>
        
        <div class="download_data container">
        <h3 class="or_co">Download</h3>
        <div class="news_link">
            <ul class="inner_list">
                <li><a href="#">COVID-19 Guidelines & Instructions (Gujarati)</a></li>
                <li><a href="#">COVID-19 Guidelines & Instructions (English)</a></li>
                <li><a href="#">Asiatic Lion Poonam Avlokan 2020</a></li>
                <li><a href="#">Gujarati Press Release Satellite Telemetry of Lesser Florican in Saurashtra-note</a></li>
                <li><a href="#">Poonam Avlokan Press Note</a></li>
                <li><a href="#">English Press Release Satellite Telemetry of Lesser Florican in Saurashtra-note</a></li>
                <li><a href="#">English Press Release Satellite Telemetry of Vultures in Gujarat 2020</a></li>
                <li><a href="#">Gujarati Press Release Satellite Telemetry of Vultures in Gujarat 2020</a></li>
                <li><a href="#">Radio Telemetry Leopard Gir 2021 English</a></li>
                <li><a href="#">Radio Telemetry Leopard Gir 2021Gujarati</a></li>
                <li><a href="#">Gir Darpan</a></li>
                <li><a href="#">Status of Wildlife in Gir Interpretation Zone</a></li>
                <li><a href="#">World Lion Day 2020 Report</a></li>
                <li><a href="#">Wild Herbivores in Gir</a></li>
                <li><a href="#">Gir Booklet</a></li>
                <li><a href="#">Gujarati Press Release Satellite Telemetry of Raptors in Gujarat 2021</a></li>
                <li><a href="#">English Press Release Satellite Telemetry of Raptors in Gujarat 2021</a></li>
                <li><a href="#">Lion Day 2021 Drawing English Gujarati</a></li>
                <li><a href="#">Lion Day 2021 Photgraphy English Gujarati</a></li>
                <li><a href="#">Lion Day 2021 Drawing and Photography Result</a></li>
            </ul>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>