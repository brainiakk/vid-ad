<?php $__env->startSection("content"); ?>
<?php if($event['type'] == 2): ?>
<section class="b_form container">
   <div class="b_details">
      <div class="data_first row">
         <div class="b_title col-sm-8 col-xs-8 or_co">
            Booking Detail: <strong class="ma_co"><span>Devalia Park Bus Safari</span></strong>
         </div>
      </div>
      <hr>
      <form method="post" action="">
       
        <input type="hidden" name="type" value="<?php echo e($event['type']); ?>">
         <div class="data_second row">
            <div class="col-sm-3 col-xs-12">
               <label class="control-label form-label">Date</label><br>
               <input type="date" name="event" value="<?php echo e($event['visit']); ?>" disabled="disabled">
            </div>
            <div class="col-sm-3 col-xs-12">
               <label class="control-label form-label">Timing</label>
               <select name="timing"  class="timing form-control" disabled="disabled">
                  <option value="<?php echo e($event['time']); ?>"><?php echo e($event['time']); ?></option>
               </select>
            </div>
            <div class="col-sm-3 col-xs-12">
               <label class="control-label form-label">Indian</label>
               <input name="indian" type="text" value="<?php echo e($event['indian']); ?>" maxlength="3" id="indian"  disabled="disabled" class="aspNetDisabled form-control">
            </div>
            <div class="col-sm-3 col-xs-12">
               <label class="control-label form-label">Foreigner</label>
               <input name="foreigner" type="text" value="<?php echo e($event['foreigner']); ?>"  maxlength="3" id="foreigner"  disabled="disabled" class="aspNetDisabled form-control">
            </div>
         </div>
         <div class="box_bac">
            <div class="b_person">
               <div class="b_titles or_co">
                  Booking <span class="ma_co">Person Details</span>
               </div>
               <hr>
               <div class="form_data">
                  <div class="row">
                     <div class="col-sm-3 col-xs-12">
                        <label class="control-label form-label">First Name</label><br>
                        <input type="text" id="first_name" name="first_name" class="i_text" maxlength="50">
                     </div>
                     <div class="col-sm-3 col-xs-12">
                        <label class="control-label form-label">Last Name</label><br>
                        <input type="text" id="last_name" name="last_name" class="i_text">
                     </div>
                     <div class="col-sm-3 col-xs-12">
                        <label class="control-label form-label">Mobile Number</label><br>
                        <input type="text" id="number"  name="mobile" class="i_text">
                     </div>
                     <div class="col-sm-3 col-xs-12">
                        <label class="control-label form-label">Email ID</label><br>
                        <input type="text" id="email" name="email" class="i_text">
                     </div>
                  </div>
                  <div class="address">
                     <label class="control-label form-label">Address</label><br>
                     <!-- <input type="textarea" id="address" class="i_text"> -->
                     <textarea name="address" id="address" class="i_text" rows="2"></textarea>
                  </div>
                  <div class="check_box">
                     <input type="checkbox" id="pamision" name="pamision" value="pamision">
                     <label for="pamision">I am not travelling, I am booking permits for someone else.</label><br>
                  </div>
               </div>
               <div class="box_bac">
                  <div class="b_person">
                     <div class="b_titles or_co">
                        Booking <span class="ma_co">Person Details</span>
                     </div>
                     <hr>
                     <div class="tabel">
                        <table border="1">
                           <tr class="t_title">
                              <th>Age</th>
                              <th>Gender</th>
                              <th>Nationality</th>
                              <th>Country</th>
                           </tr>
                           <tr>
                              <td>
                                 <input type="number" class="t_box">
                              </td>
                              <td>
                                 <select name="gender" class="gender form-control t_box">
                                    <option>---Please Select---</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                 </select>
                              </td>
                              <td>
                                 <select name="country" class="nationality form-control t_box">
                                    <option>---Please Select---</option>
                                    <option value="india">India</option>
                                    <option value="forrigner">Forrigner</option>
                                 </select>
                              </td>
                              <td>
                                 <select name="nationality" class="nationality form-control t_box">
                                    <option>---Please Select---</option>
                                    <option value="india">India</option>
                                    <option value="forrigner">Forrigner</option>
                                 </select>
                              </td>
                           </tr>
                        </table>
                     </div>
                     <div class="p_details">
                        <div class="b_titles or_co">
                           <span class="ma_co">Proof</span> Details
                        </div>
                        <hr>
                        <div class="p_data">
                           <div class="col-sm-12 col-sm-12">
                              <h6>Note: If foreigner please enter passport details.</h6>
                           </div>
                           <div class="row">
                              <div class="col-sm-3 col-xs-12">
                                 <label class="control-label form-label">Please Select Document</label><br>
                                 <select name="selectProof" class="form-control t_box">
                                    <option>---Please Select---</option>
                                    <option value="aadhar_card">Aadhar Card</option>
                                    <option value="passport">Passport</option>
                                    <option value="school_card">School Card</option>
                                 </select>
                              </div>
                              <div class="col-sm-3 col-xs-12">
                                 <label class="control-label form-label">Proof Number</label><br>
                                 <input type="text" id="lname" maxlength="20" style="width: 100%;padding:5px">
                              </div>
                           </div>
                           <div class="check_box" style="margin-top: 10px;">
                              <input type="checkbox" id="pamision" name="pamision" value="pamision">
                              <label for="pamision">I read all <a href="#" style="color: #007BFF;">terms & condition</a> mentioned and agree to it.</label><br>
                           </div>
                        </div>
                     </div>
                     <div class="pay_body">
                        <div class="price">
                           <h3>₹4500</h3>
                        </div>
                        <div class="total_price row">
                           <div class="col-sm-5"> Total </div>
                           <div class="col-sm-3"></div>
                           <div class="col-sm-4">
                              <input type="submit" id="send_form" name="btnProceed" value="Pay Now" id="btnProceed" class="btn btn-pay">
                              <input type="submit" name="btnCancel" value="Cancel" id="btnCancel" class="btn btn-cancel">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </form>
   </div>
</section>
<?php else: ?>
<section class="b_form container">
    <form method="post" action="<?php echo e(route('paydetails')); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="type" value="<?php echo e($event['type']); ?>">
        <div class="b_details">
            <div class="data_first row">
                <div class="b_title col-sm-8 col-xs-8 or_co">
                    Booking Detail: <strong class="ma_co"><span>Devalia Park Bus Safari</span></strong>
                </div>
            </div>
            <hr>
            <div class="form_data">
            <div class="data_second row">
                <div class="col-sm-3 col-xs-12">
                    <label class="control-label form-label">Date</label><br>
                    <input type="date" name="visit" value="<?php echo e($event['visit']); ?>">
                </div>
                <div class="col-sm-3 col-xs-12">
                    <label class="control-label form-label">Timing</label>
                    <select name="time"  class="timing form-control">
                    <option value="<?php echo e($event['time']); ?>"><?php echo e($event['time']); ?></option>
                    </select>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <label class="control-label form-label">Number of Adult:</label>
                    <select class="form-select" name="adult" require >
                    <option value="<?php echo e($event['adult']); ?>"><?php echo e($event['adult']); ?></option>
                    </select>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <label class="control-label form-label">Number of Child :</label>
                    <select class="form-select" name="child" require >
                        <option value="<?php echo e($event['child']); ?>"><?php echo e($event['child']); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <div class="box_bac">
            <div class="b_person">
                <div class="b_titles or_co">
                    Booking <span class="ma_co">Person Details</span>
                </div>
                <hr>
                <div class="form_data">
                    <div class="row">
                        <div class="col-sm-3 col-xs-12">
                            <label class="control-label form-label">First Name</label><br>
                            <input type="text" id="first_name" name="first_name" class="i_text"  maxlength="50">
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <label class="control-label form-label">Last Name</label><br>
                            <input type="text" id="last_name" name="last_name" class="i_text">
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <label class="control-label form-label">Mobile Number</label><br>
                            <input type="text" id="number"  name="mobile" class="i_text">
                        </div>
                        <div class="col-sm-3 col-xs-12">
                            <label class="control-label form-label">Email ID</label><br>
                            <input type="text" id="email" name="email" class="i_text">
                        </div>
                    </div>
                    <div class="address">
                        <label class="control-label form-label">Address</label><br>
                        <textarea name="address" id="address" class="i_text" rows="2"></textarea>
                    </div>
                    <div class="check_box">
                        <input type="checkbox" id="pamision" name="pamision" value="pamision">
                        <label for="pamision">I am not travelling, I am booking permits for someone else.</label><br>
                    </div>
                </div>
                <?php  $adult= $event['adult']; 
                    $child= $event['child']; 
                ?>
                <div class="container">
                    <div class="table">
                        <table border="1" class="table table-striped">
                            <thead>
                                <tr class="t_title">
                                    <th>NO</th>
                                    <th>Type</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                    <th>Nationality</th>
                                    <th>Country</th>
                                    <th>Select Proof</th>
                                    <th>Upload Proof</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i = 1; $i <=$adult; $i++): ?>
                                <tr>
                                    <td >
                                        <?php echo e($i); ?>

                                    </td>
                                    <td>
                                        <span id="demo">Adult</span>
                                        <input id="total" type="hidden" name="person" value="">
                                    </td>
                                    <td>
                                        <input type="text" name="first_name"> 
                                    </td>
                                    <td>
                                        <input type="text" name="last_name"> 
                                    </td>
                                    <td>
                                        <input type="number" name="age">
                                    </td>
                                    <td>
                                        <select name="gender" required>
                                            <option>--Gender--</option>
                                            <option value="male">male</option>
                                            <option  value="female">female</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="nationality" id="" required>
                                            <option>--Nationality--</option>
                                            <option value="indian">Indian</option>
                                            <option value="foreigner">foreigner</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="country" id="" required>
                                            <option>--Country--</option>
                                            <option value="indian">Indian</option>
                                            <option value="foreigner">foreigner</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="selectProof" >
                                            <option>---Please Select---</option>
                                            <option value="aadhar_card">Aadhar Card</option>
                                            <option value="driving_licence">Driving Licence</option>
                                            <option value="election_card">Election Card</option>
                                            <option value="passport">Passport</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="file" name="selectUpload">
                                    </td>
                                </tr>
                                <?php endfor; ?>
                                <?php for($i = $adult+1; $i <=$adult+$child; $i++): ?>
                                <tr>
                                    <td >
                                        <?php echo e($i); ?>

                                    </td>
                                    <td >
                                      
                                      <span id="demo">child</span>
                                      <input id="total" type="hidden" name="person" value="">
                                    </td>
                                    <td>
                                        <input type="text" name="first_name"> 
                                    </td>
                                    <td>
                                        <input type="text" name="last_name"> 
                                    </td>
                                    <td>
                                        <input type="number" name="age">
                                    </td>
                                    <td>
                                        <select name="gender"  required>
                                            <option >--Gender--</option>
                                            <option  value="male">male</option>
                                            <option  value="female">female</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="nationality" >
                                            <option >--Nationality--</option>
                                            <option value="indian">Indian</option>
                                            <option value="foreigner">foreigner</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="country" >
                                            <option >--Country--</option>
                                            <option value="indian">Indian</option>
                                            <option value="foreigner">foreigner</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="selectProof" >
                                            <option>---Please Select---</option>
                                            <option value="aadhar_card">Aadhar Card</option>
                                            <option value="driving_licence">Driving Licence</option>
                                            <option value="election_card">Election Card</option>
                                            <option value="passport">Passport</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="file" name="selectUpload">
                                    </td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="pay_body">
                    <div class="price">
                        <h3>₹4500</h3>
                    </div>
                    <div class="total_price row">
                        <div class="col-sm-5"> 
                            Total 
                        </div>
                        <div class="col-sm-3">
                            
                        </div>
                        <div class="col-sm-4">
                            <input type="submit" id="send_form" name="btnProceed" value="Pay Now" id="btnProceed" class="btn btn-pay">
                            <input type="submit" name="btnCancel" value="Cancel" id="btnCancel" class="btn btn-cancel">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</section>
<script>
    var data = $('#demo').html();
$('#total').val(data);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>