<?php $__env->startSection('content'); ?>


































































































<div class="col-md-12 contents">
    <div class="row justify-content-center">
        <div class="col-md-6 bg-light border rounded py-3">

            <div class="mb-4 text-center">
                <!-- <div class="text-center">
                    <img class="logo" src="assets/images/logo.png">
                </div> -->
                <h3>Sign Up</h3>
                <p class="mb-4">Start with your free account today</p>
            </div>

            <form action="<?php echo e(url('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <?php if($errors->any()): ?>
                    <div class="form-group col-12 alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="form-group first mb-3">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group first mb-3">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="form-group last mb-4">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password">
                </div>

                <div class="form-group last mb-4">
                    <label for="password">Confirm Password</label>
                    <input type="password" class="form-control" id="password-confirm" name="password_confirmation" required autocomplete="new-password">
                </div>
                <div class="form-group last mb-4">
                    <label for="phone_number"
                           ><?php echo e(__('Phone Number')); ?></label>

                        <input id="phone_number" type="text"
                               class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone_number"
                               value="<?php echo e(old('phone_number')); ?>" required>

                        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($phone_number); ?></strong>
                                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group first mb-3">
                    <label for="location">Location</label>
                    <select class="form-control" id="location" name="location">
                        <option>USA</option>
                        <option>Europe</option>
                        <option>Canada</option>
                        <option>Asia</option>
                    </select>
                </div>
                <div class="form-group first mb-3">
                    <label for="age">Age</label>
                    <input type="number" class="form-control" id="age" name="age" value="<?php echo e(old('age')); ?>">
                </div>
                <div class="form-group first mb-3">
                    <label for="gender">Gender</label>
                    <select class="form-control" id="gender" name="gender">
                        <option>Male</option>
                        <option>Female</option>
                    </select>
                </div>
                <input type="submit" value="Sign Up" class="btn btn-block btn-primary py-3" style="background:#159AFF;border-color: #159AFF;">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/auth/register.blade.php ENDPATH**/ ?>