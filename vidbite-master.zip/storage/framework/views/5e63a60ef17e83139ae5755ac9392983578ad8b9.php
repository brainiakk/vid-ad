<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" >
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.min.js"> </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" ></script>
<link href="<?php echo e(asset('css/appp.css')); ?>" rel="stylesheet" type="text/css" >

<footer class="footer_section">
        
        <div class="inner-footer">
            <div class="container">
                <div class="row footer_first"> 
                    <div class="col-md-3 col-sm-6 col-xs-12 text-left label">Subscribe For Our Latest Updates</div>
                    <div class="col-md-4 col-sm-6 col-xs-12 jj">
                        <input type="email" id="email">
                        <button type="button"><i class="fab fa-telegram-plane"></i></button>                           
                    </div>
                    <div class="col-md-5 col-sm-12 col-xs-12 social-icon">
                        <ul class="s_icon">
                            <div><h5 class="icon">Follow Us on:</h5></div>
                            <li><a href="#"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fab fa-youtube-square"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="footer_second">
                    <ul class="footer_menu">
                        <li><a href="<?php echo e(route('importantlinks')); ?>">Important Links</a></li>
                        <li><a href="<?php echo e(route ('privacypolicy')); ?>">Privacy Polices</a></li>
                        <li><a href="<?php echo e(route ('faq')); ?>">FAQ</a></li>
                        <li><a href="<?php echo e(route ('termsconditon')); ?>">T&C</a></li>
                        <li><a href="<?php echo e(route('contactus')); ?>">Contact Us</a></li>
                    </ul>
                </div>
                <div class="row footer_third">
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <h6>Last Update: 23/08/2021</h6>
                        <h6>Total Visitors : 999139</h6>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <h6>©2021 GSLCS. All Rights Reserved.</h6>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <h6>Developed By : <a href="#">VOCSY INFOTECH</a>.</h6>
                    </div>
                </div>
            </div>
        </div>
    </footer>