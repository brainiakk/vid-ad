<?php $__env->startSection("content"); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
<div class="container">
	<div class="row">
        <section class="booking">
			<div class="container">
				<div class="booking_back_img">
					<img src="<?php echo e(asset('/image/background_image.png')); ?>" alt="booking Image">
					<div class="booking_form">
						<h2 class="title text-center">Booking For Gir Jungle Safari</h2>
						<form method="POST" action="<?php echo e(route('Gironline')); ?>" >
							<?php echo e(csrf_field()); ?>

						<input type="hidden" name="type" value="1">
							<div class="mb-3">
								<label >Visit Date :</label><br>
								<input type="date" id="visit" name="visit">
							</div>
							<div class="mb-3">
								<label class="form-label">Timing :</label>
								<select class="form-select" name="time" require>
									<option>--Please Select--</option>
									<option value="6 am to 9 am">6 am to 9 am</option>
									<option value="8:30 am to 11:30 am">8:30 am to 11:30 am</option>
									<option value="4:00 pm to 7:00 pm">4:00 pm to 7:00 pm</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label">Number of Adult:</label>
								<select class="form-select" name="adult" require>
									<option>--Please Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
								</select>
							</div>
							<div class="mb-3">
								<label class="form-label" >Number of Child :</label>
								<select class="form-select" name="child" require>
									<option>--Please Select--</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
								</select>
							</div>
							<button type="submit" name="submit" class="btn btn-primary" >save</button>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>