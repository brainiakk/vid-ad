<?php $__env->startSection('content'); ?>

<div class="page-title">
    <div class="row">
      <div class="col-sm-6">
          <h4 class="mb-0"> Dashboard</h4>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
          <li class="breadcrumb-item"><a href="/" class="default-color">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('superadmin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/superadmin/dashboard/index.blade.php ENDPATH**/ ?>