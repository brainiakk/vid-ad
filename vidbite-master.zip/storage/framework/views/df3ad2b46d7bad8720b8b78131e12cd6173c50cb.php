<?php $__env->startSection("content"); ?>

<section class="gallery_photo">
        <div class="gallery_slider">
            <div class="slider_background">
                <img src="<?php echo e(asset('/image/gallery_slider.png')); ?>" alt="gallery img">
            </div>
            <div class="gallery_title">
                <h3>Representative Images</h3>
            </div>
        </div>
        <div class="gallery_img container">
            <div class="row">
                <div class="imageGallery">
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery1.jpg')); ?>" alt="Gallery_1">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery2.jpg')); ?>" alt="Gallery_2">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery3.jpg')); ?>" alt="Gallery_3">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery4.jpg')); ?>" alt="Gallery_4">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery5.jpg')); ?>" alt="Gallery_5">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery6.jpg')); ?>" alt="Gallery_6">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery7.jpg')); ?>" alt="Gallery_7">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery8.jpg')); ?>" alt="Gallery_5">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery9.jpg')); ?>" alt="Gallery_2">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery10.jpg')); ?>" alt="Gallery_1">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery11.jpg')); ?>" alt="Gallery_2">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery12.jpg')); ?>" alt="Gallery_3">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/gallery13.jpg')); ?>" alt="Gallery_4">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/1.jpg')); ?>" alt="Gallery_5">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/2.jpg')); ?>" alt="Gallery_6">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/3.jpg')); ?>" alt="Gallery_7">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/4.jpg')); ?>" alt="Gallery_5">
                    </a>
                    <a href="#">
                        <img src="<?php echo e(asset('/image/5.jpg')); ?>" alt="Gallery_2">
                    </a>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>