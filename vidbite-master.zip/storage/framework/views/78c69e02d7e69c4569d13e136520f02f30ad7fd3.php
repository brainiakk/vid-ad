<?php $__env->startSection('title', 'User Management'); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
            <div class="heading">
                <h2>User Management System</h2>
                <div class="d-flex justify-content-end">
                    <a href="<?php echo e(route('createUser')); ?>" class="btn btn-warning mb-2">Add</a>
                </div>
            </div>
            <table id="example" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">User Role</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->name != 'Admin'): ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->user_type); ?></td>
                                <td>
                                    <?php if($user->is_active == 1): ?>
                                        <span class="label label-success">Approved</span>
                                    <?php else: ?>
                                        <span class="label label-danger">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <?php if($user->is_active != 1): ?>
                                            <div class="mr-4">
                                                <form method="POST" action="<?php echo e(route('verifyUser', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-success">Verify User</button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                        <div class="edit-button mr-4">
                                            <a href="<?php echo e(route('editUser', $user->id)); ?>" class="btn btn-primary">EDIT</a>
                                        </div>
                                        <div class="delete-button">
                                            <!-- <a href="" class="btn btn-danger">DELETE</a> -->
                                            <form method="POST" action="<?php echo e(route('deleteUser', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-danger">DELETE</button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/user-management.blade.php ENDPATH**/ ?>