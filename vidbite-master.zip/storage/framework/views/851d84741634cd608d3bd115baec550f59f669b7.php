<?php $__env->startSection("content"); ?>
<!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" > -->
<!-- <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css"> -->
<!-- <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/> -->

<section class="marquee-text"> 
        <marquee width="100%" direction="left" onmouseover="stop()" onmouseout="start()">
            This is the only official booking website for Gir Online Permit Booking System.
        </marquee>
    </section>
<section class="header-slider">
        <div class="slick_slider ">
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/1.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/2.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/3.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/4.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/5.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/6.jpg')); ?>" alt="Lion 1">
            </div>
            <div class="slider-img">
                <img src="<?php echo e(asset('/image/7.jpg')); ?>" alt="Lion 1">
            </div>
        </div>
        <div class="slider_top col-sm-12">
            <div class="media">
                <img src="<?php echo e(asset('/image/gir-trail.png')); ?>" alt="">
                <div class="media-body">
                    <h3>Gir Jungle Safari</h3>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div>
            <div class="media">
                <img src="<?php echo e(asset('/image/gypsy-safari.png')); ?>" alt="">
                <div class="media-body">
                    <h3>Gir Jungle Safari</h3>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div>
            <div class="media">
                <img src="<?php echo e(asset('/image/bus-safari.png')); ?>" alt="">
                <div class="media-body">
                    <h3>Gir Jungle Safari</h3>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div>
            <!-- <div class="media">
                <img src="<?php echo e(asset('/image/bus-safari.png')); ?>" alt="">
                <div class="media-body">
                    <h3>Gir Jungle Safari</h3>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div>
            <div class="media">
                <img src="<?php echo e(asset('/image/gir-trail.png')); ?>" alt="">
                <div class="media-body">
                    <h3>Gir Jungle Safari</h3>
                    <a href="#" class="btn btn-primary">Book Now</a>
                </div>
            </div> -->
        </div>
</section>
    <section class="container park-description">
        <div class="description">
            <h4 class="text-center title">GIR NATIONAL PARK THE HOME OF MAJESTIC ASIATIC LION</h4>
            <p>Gir National Park and Wildlife Sanctuary, also known as Sasan Gir, is a forest, national park, and wildlife sanctuary near Talala Gir in Gujarat, India. It is located 43 km (27 mi) north-east of Somnath, 65 km (40 mi) south-east of Junagadh and 60 km (37 mi) south-west of Amreli. It was established in 1965 in Nawab of Junagarh private hunting area, with a total area of 1,412 km2 (545 sq mi), of which 258 km2 (100 sq mi) is fully protected as national park and 1,153 km2 (445 sq mi) as wildlife sanctuary. It is part of the Khathiar-Gir dry deciduous forests ecoregion.</p>
        </div>
    </section>
    <section class="container time_table"> 
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 table_left">
                <h4 class="text-center">CANCELLATION RULES</h4>
                <div class="safari_time">
                    <button class="tablink" onclick="openPage('gir_jungle', this, '#E74900')" id="defaultOpen">Gir Jungle Trail</button>
                    <button class="tablink" onclick="openPage('devalia_safari', this, '#E74900')" >Devalia Safari Park</button>
                    <div id="gir_jungle" class="tabcontent">
                        <table class="table table-bordered" border="1px solid" style="border-color: #A2601A;">
                            <thead class="tab_color">
                                <th>Days</th>
                                <th>Morning Timings</th>
                                <th>Evening Timings</th>
                            </thead>
                            <tbody class="tab_color">
                                <tr>
                                    <td rowspan="5">Monday To Sunday</td>
                                    <tr>
                                        <td>6:45 AM to 9:45 AM  </td>
                                        <td>3 PM to 6 PM</td>
                                    </tr>
                                    <tr>
                                        <td>6:00 AM to 9:00 AM</td>
                                        <td>4 PM to 7 PM</td>
                                    </tr>
                                    <tr>
                                        <td>8:30 AM to 11:30 AM </td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Gir Safari Booking Timings</th>
                                    </tr>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="devalia_safari" class="tabcontent">
                        <table class="table table-bordered" border="1px solid" style="border-color: #A2601A;">
                            <thead class="tab_color">
                                <th>Days</th>
                                <th>Morning Timings</th>
                                <th>Evening Timings</th>
                            </thead>
                            <tbody class="tab_color">
                                <tr>
                                    <td rowspan="5">Monday To Sunday</td>
                                    <tr>
                                        <td>7 AM To 7:55 AM</td>
                                        <td>3 PM To 3:55 PM</td>
                                    </tr>
                                    <tr>
                                        <td>8 AM To 8:55 AM</td>
                                        <td>4 PM To 4:55 PM</td>
                                    </tr>
                                    <tr>
                                        <td>9 AM To 9:55 AM</td>
                                        <td>5 PM To 5:55 PM</td>
                                    </tr>
                                    <tr>
                                        <td>10 AM To 10:55 AM</td>
                                        <td></td>
                                    </tr>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 table_right text-center">
                <h4>CANCELLATION RULES</h4>
                <table class="table table-bordered" border="1px solid" style="border-color: #A2601A;">
                    <thead class="first_title">
                        <tr>
                            <th class="h_first" colspan="3">Gir Jungle Trail and Devalia Safari Park</th>
                        </tr>
                        <tr class="tab_color">
                            <th scope="col">Particulars</th>
                            <th scope="col">Refund Percentage</th>
                        </tr>
                    </thead>
                    <tbody class="tab_color">
                        <tr>
                            <td>Before 10 Days</td>
                            <td>75%</td>
                        </tr>
                        <tr>
                            <td>Before 5 Days</td>
                            <td>50%</td>
                        </tr>
                        <tr>
                            <td>Before 2 Days</td>
                            <td>25%</td>
                        </tr>
                        <tr>
                            <td>Less than 2 Days</td>
                            <td>No Refund.</td>
                        </tr>
                    </tbody>
                    </table>
            </div>
        </div>
    </section>
    <section class="container covid_safety">
        <h3 class="text-center">COVID 19 SAFETY INSTRUCTIONS FOR VISITORS</h3>
        <div class="safety_note">
            <p>Avoid Visit If You Have Any Symptoms Of COVID-19.</p>
            <hr>
            <p>Persons Above 65 Years Of Age, Persons With Comorbidities, Pregnant Women And Children Below The Age Of 10 Years Are Advised To Stay At Home.</p>
            <hr>
            <p>Face Masks/Shields Are Compulsory For All The Visitors Including Eco-Guides And Safari Vehicle Drivers.</p>
            <hr>
            <p>Visitors Are Advised To Carry The Sanitizers And Use Them As And When Required.</p>
            <hr>
            <p>It’s Better To Avoid Touching Surfaces As Much As Possible.</p>
            <hr>
            <p>મુલાકાતીઓ માટે મહત્વપુર્ણ સુચનાઓ</p>
            <hr>
            <p>જો આપને કોવિડ-૧૯ ના કોઇ પણ લક્ષણો હોય તો મુલાકાત ટાળશો.</p>
            <hr>
            <p>10 વર્ષથી ઓછી ઉંમરના બાળકો અને 65 વર્ષથી વધુ ઉંમરના વ્યક્તિઓ, સગર્ભા સ્ત્રીઓ તથા બહુવિધ રોગ ધરાવતા વ્યક્તિઓને ઘરે રહેવાની સલાહ આપવામાં આવે છે.</p>
            <hr>
            <p>ઇકો-ગાઇડસ અને સફારી વાહન ચાલકો સહિતના બધા મુલાકાતીઓએ ફેસ માસ્ક/ શિલ્ડ ફરજીયાત પહેરવાના રહેશે.</p>
            <hr>
            <p>મુલાકાતીઓએ સેનિટાઇઝર લઈ આવવા અને જરૂરીયાત જણાય ત્યારે તેનો ઉપયોગ કરવાની સલાહ આપવામાં આવે છે.</p>
            <hr>
            <p>શક્ય હોય તેટલી વસ્તુ / સપાટીઓને સ્પર્શ કરવાનું ટાળવું.</p>
        </div>
    </section>
    <section class="container safari_booking">
        <h4 class="text-center title">GIR LION SAFARI BOOKING</h4>
          <div class="row"> 
              <div class="col-sm-4 col-xs-12 text-center book_first">
                   <div class="booking">
                        <h5 class="te_br">Gir Jungle Trail</h5>
                        <img src="<?php echo e(asset('/image/book_first.jpg')); ?>" alt="Book First">
                        <p>Gir Is One Of India’s Oldest Sanctuaries, And Is Synonymous With The Majestic Asiatic Lion (Panthera Leo Persica).</p>
                        <a href="#" class="btn_br btn btn-primary">Read More...</a>
                   </div>
              </div>
              <div class="col-sm-4 col-xs-12 text-center book_second">
                   <div class="booking">
                        <h5 class="te_br">Gir Jungle Trail</h5>
                        <img src="<?php echo e(asset('/image/book_second.jpg')); ?>" alt="Book First">
                        <p>Devalia Safari Park Also Known As Gir Interpretation Zone - Devalia, Is The Establishment Of Particular Eco-Tourism Zone To Reduce Overload ....</p>
                        <a href="#" class="btn_br btn btn-primary">Read More...</a>
                   </div>
              </div>
              <div class="col-sm-4 col-xs-12 text-center book_third">
                   <div class="booking">
                        <h5 class="te_br">Gir Jungle Trail</h5>
                        <img src="<?php echo e(asset('/image/book_third.jpg')); ?>" alt="Book First">
                        <p>Gir Forest Visit And To Provide Whole Wildlife Of Gir At Single Place In Safe Habitats.This Interpretation Zone Comprises Of 412 Ha Chain Link Fenced Area...</p>
                        <a href="#" class="btn_br btn btn-primary">Read More...</a>
                   </div>
              </div>
          </div>                                          
    </section>
    <section class="container park_data">
        <div class="gir">
            <h4 class="sub_title text-center">GIR NATIONAL PARK</h4>
            <p>The Thought To Meet And Greet The Mighty Lion Is As Fascinating As It Is Frightening. But, 
                If You Are Eager To Have Such A Fulfilling Experience, Then The <span class="te_br">Gir National Park</span> 
                Is The Destination For You.
            </p>
            <p>Our Geography And General Knowledge Books Have Introduced Us To This Famous Wildlife Sanctuary, The Gir 
                National Park Which Is Located In Gujarat. This Protected Forest Is Also Popular As 
                <span class="te_br">SasanGir</span> And Is Located Near Somnath, Junagadh, Amreli, And Especially The 
                TalalaGir. In 1965, The Gir Forest National Park Was Set Up And Since Then It Has Been The Refuge For 
                Mama(201), Papa(109l), And Baby Lions (213). The National Park And Wildlife Sanctuary Has An Area Of 
                1412 Km2 Combined And Has Been Attracting People Since Its Inception.
            </p>
            <p>To Gather The Best Memories, You Need To Visit The Gir Forest During December To March, As It Remains 
                Closed Every Year For The Set Period Of June 16- October 15. However, If You Are A Fan Of Photography 
                And Can Dread The Hotness Of Gujarat, Then You Will Be Impressed With April- May Scenes. To Make The 
                Most Of The Journey, <span class="te_br">Gir Safari Booking</span> Will Be The Best Idea.
            </p>
        </div> 
        <div class="history">
            <h4 class="sub_title text-center">HISTORY OF GIR NATIONAL PARK</h4>
            <p>When We Were Still Under The British Rule, Then The Colonized Princes Used To Invite Colonizers For The 
                Game Of Hunt. This Led To A Steady Decline In The Count Of The Asiatic Lion And Only A Dozen Or So Were 
                Left Cornered In The Gir Forest. This Was Brought To The Notice Of Junagarh's Nawab As This Hunting 
                Ground Belonged To Him. To Preserve The Remaining Precious Asiatic Lion, He Established The 
                <span class="te_br">Gir National Park</span> Which Also Houses Various Other Plants And Animals.
            </p> 
            <p>The Bio-Diverse Importance Of This Place Is Immense And The NGOs, The Wildlife Activists, And The Forest 
                Department Of Government Are Trying Their Utmost To Protectthe <span class="te_br">Gir Forest National Park.</span>
            </p>                                      
        </div>
        <div class="online_book">
            <h4 class="sub_title text-center">ONLINE GIR SAFARI BOOKING DETAILS</h4>
            <p>The Charm Of Viewing The Majestic Animal From An Open Jeep Is Magnetic And Undeniable And That Is Why We 
                Stress On <span class="te_br">Gir Safari Booking.</span> To Understand The True Essence Of The Gir Forest 
                And To Make The Journey, Booking A Jeep Safari Is A Must. The Twilight Zone, Dusk, And Dawn Are Best To 
                Get A Glimpse Of Them, So The Safari Is Available Both In The Evening And Morning.
            </p>
            <h5 class="head">The Timing:</h5>
            <ul class="content">
                <li>Mid October till February: 6:45 AM – 9:45 AM// 8:30 AM – 11:30 AM and 3:00 PM -6PM.</li>
                <li>March till June: 6:00AM-9:00AM// 8:30AM-11:30AM and 4:00 PM-7:00PM</li>
            </ul>
            <p>The Online Procedure Of Booking SasanGir Safari Is Very Easy, But You Need To Remember That You Should 
                Book It Earlier To Get The Slots As Everyone Wishes To Hit The Bull's Eye. For A Successful Booking, 
                You Need To Provide:
            </p>
            <ul class="content">
                <li>The full name of each candidate</li>
                <li>Preferred slot for checking out the Gir Forest National Park</li>
                <li>Identity proof: Voter ID/ Aadhaar/ Driving License/ Passport</li>
                <li>Carrying the provided proof during safari</li>
            </ul>
            <p>The Gir Safari Booking Fees Include Permit, Guide, Driver, Jeep, One Camera Charges As Well As The 
                Gateway Charges For Online Payment, Drop, And Pick-Up Facility From Resorts And Hotel On Extra Charges.
            </p>
            <p>You Also Need To Remember A Few Gir National Park Information About Booking Cancellation That You Cannot 
                Transfer, Exchange, Or Resell The Already Reserved Seats.You Are Eligible For A Refund Only If You 
                Cancel Your SasanGir Safari 2 Days Before The Actual Date.
            </p>
            <ul class="content">
                <li>75% refund for canceling before 10 days,</li>
                <li>50% if done before 5 days, and</li>
                <li>25% if done before 2days</li>
            </ul>
        </div>  
        <div class="bus_jeep">
            <h4 class="sub_title text-center">THE ULTIMATE GIR SAFARI BOOKING DEBATE: BUS OR JEEP?</h4>
            <h6 class="head">Devalia Safari Park</h6>
            <p>There Is Absolutely No Doubt About The Fact That The Gir Forest National Park Has A Lot To Offer. Keeping In 
                Mind The Requirements Of The Inhabitants Of The Gir Forest, TheDevalia Safari Was Created. Devalia Is An 
                Interpretation Of The Denser Forest Which Gives To You All The Main Components Of The Main Theme But In 
                A Restricted Zone.
            </p>
            <p>On The Other Hand, The Devalia Safari Is About A Bus-Ride Through The Less-Dense Part Of The 
                <span class="te_br">GirNational Park</span> Which Might Not Be Very Adventurous Yet Guarantees The Sightings 
                Of The Animals. This Safari Is On Throughout The Day And Can Introduce You With Birds, Reptiles, 
                Herbivorous Other Than The Lions.
            </p>  
            <h6 class="head">Gir Jungle Trail</h6>
        </div>                                        
    </section>

    <script>
        function openPage(pageName,elmnt,color) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].style.backgroundColor = "";
        }
        document.getElementById(pageName).style.display = "block";
        elmnt.style.backgroundColor = color;
        }
        document.getElementById("defaultOpen").click();
    </script>
    <script src="<?php echo e(asset ('js/jquery-1.11.0.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script src="<?php echo e(asset ('js/script.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>