<?php $__env->startSection("content"); ?>

<section class="container service">
        <div class="coll_service">
            <button class="collapsible"><a href="#">Services</a></button>
            <div class="content panel_body">
                <div class="row first">
                    <div class="col-sm-4 col-xs-12 inner_service">
                        <div class="icon1">
                            <i class="fa fa-user"></i>
                        </div>
                        <div class="service_title">Guide</div>
                        <p>Guides are locally available at the Reception Centre, Sinh Sadan, Sasan. they have been trained and authorized..
                            <br>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </p>
                    </div>
                    <div class="col-sm-4 col-xs-12 inner_service">
                        <div class="icon1">
                            <i class="fa fa-bus"></i>
                        </div>
                        <div class="service_title">Vehicle</div>
                        <p>Private vehicles (Gypsy) are locally available at Reception Centre, Sinh Sadan, Sasan...
                            <br>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </p>
                    </div>
                    <div class="col-sm-4 col-xs-12 inner_service">
                        <div class="icon1">
                            <i class="fa fa-camera"></i>
                        </div>
                        <div class="service_title">Camera</div>
                        <p>Camera fee for amateur photography is Rs. 200 for Indian National and Rs. 1400 for Foreigner...
                            <br>
                            <a href="#" class="btn btn-primary">Read More</a>
                        </p>
                    </div>
                </div>
            </div>
            <button class="collapsible"><a href="#">Orientation Centre</a></button>
            <div class="content panel_body">
                <div class="row second">
                    <div class="col-sm-6 col-xs-12">
                        <img src="<?php echo e(asset('/image/service.jpg')); ?>" alt="">
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <h5>Gir Orientation Centre within the premises of Sasan Guest House Campus is an interesting place that enriches visitors with essential, accurate and scientific information on Gir Forest. Interactive photographs, paintings and models of the reserve describe its transition and present status.</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <button class="collapsible"><a href="#">Souvenir Shop</a></button>
            <div class="content panel_body">
                <div class="row second">
                    <div class="col-sm-6 col-xs-12">
                        <img src="<?php echo e(asset('/image/service2.jpg')); ?>" alt="">
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <h5>Souvenir shops, located at Sinh Sadan Sasan and Devalia Safari Park, sell memorabilia/clothing pertaining to Asiatic Lions, Gir and its biodiversity.</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <button class="collapsible"><a href="#">Gir Arboretum & Birding Point</a></button>
            <div class="content panel_body">
                <div class="row second">
                    <div class="col-sm-6 col-xs-12">
                        <img src="<?php echo e(asset('/image/service3.jpg')); ?>" alt="">
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <h5>This garden is dedicated to the collection, cultivation and display of a wide range of native medicinal plants, labelled with their botanical names. It has the majority of the tree specimens...</h5>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        var coll = document.getElementsByClassName("collapsible");
        var i;
        for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.maxHeight){
                content.style.maxHeight = null;
                } else {
                content.style.maxHeight = content.scrollHeight + "px";
                } 
            });
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>