<?php $__env->startSection("content"); ?>

<section class="gallery_photo dos_donts">
    <div class="gallery_slider">
        <div class="slider_background">
            <img src="<?php echo e(asset('/image/gallery_slider.png')); ?>" alt="gallery img">
        </div>
        <div class="gallery_title">
            <h3>DO’s & DON’Ts</h3>
        </div>
    </div>
    <div class="container dos_donts_data">
        <div class="dos">
            <h3 class="or_co">DO’s</h3>
            <ul class="inner_list">
                <li>Are you joining us for Safari? Make sure you have obtained a valid entry permit from the Gujarat Forest Department's official website (
                    <a href="#">https://girlion.gujarat.gov.in/Index.aspx </a>).
                </li>
                <li>Be an early bird – report at the reception centre at least 15 minutes before your departure time.</li>
                <li>Carry a valid identity card issued by the concerned authority.</li>
                <li>Respect the wildlife, their habits and habitat.</li>
                <li>Keep a safe distance from wildlife and observe silence.</li>
                <li>Appreciate the colours and sound of nature.</li>
                <li>Try to wear clothes that blend with the forest landscape.</li>
                <li>Drive slowly and carefully. Wildlife has its right of way.</li>
                <li>Observe the prescribed route and time limit in the forest.</li>
                <li>Photography enthusiast? – capture memories without disturbing the wildlife.</li>
                <li>Observe the sanctity of holy sites, respect the local customs.</li>
                <li>Obey the laws, rules and regulations of the Gir National Park and Sanctuary.</li>
            </ul>
        </div>
        <div class="donts">
            <h3 class="or_co">DON’Ts</h3>
            <ul class="inner_list">
                <li>Do not litter.</li>
                <li>Do not feed animals.</li>
                <li>Do not carry pets.</li>
                <li>No honking.</li>
                <li>Do not take away flora & fauna in the form of cuttings, seeds or roots.</li>
                <li>Plastic or items made up of plastic are prohibited in the forest area.</li>
                <li>No trespassing in forest area.</li>
                <li>Do not alight from the vehicle.</li>
                <li>Do not use spotlights or searchlights.</li>
                <li>Do not disturb or tease wildlife.</li>
                <li>Avoid playing any kind of musical instruments.</li>
                <li>Smoking & liquor are strictly prohibited.</li>
                <li>Do not carry weapons or explosives inside the Gir National Park and Sanctuary.</li>
                <li>Do not be disappointed if you don’t see a big cat – cherish the beauty of the landscape and other wildlife.</li>
            </ul>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>