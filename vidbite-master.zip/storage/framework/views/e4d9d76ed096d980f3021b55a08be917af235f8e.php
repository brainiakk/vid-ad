<?php $__env->startSection('title', 'Lance Master | Home Page'); ?>

<?php $__env->startSection('content'); ?>

    <div id="carousalTop" class="carousel slide mt-5" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carousalTop" data-slide-to="0" class="active"></li>
            <li data-target="#carousalTop" data-slide-to="1"></li>
            <li data-target="#carousalTop" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('assets/front/images/banner1.jpeg')); ?>" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('assets/front/images/banner2.jpeg')); ?>" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('assets/front/images/banner3.jpeg')); ?>" class="d-block w-100" alt="...">
            </div>
        </div>
        <!-- <a class="carousel-control-prev" href="#carousalTop" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousalTop" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a> -->
    </div>

    <div class="videos-row row justify-content-md-center">
        <div class="col-lg-12">
            <div class="heading">
                <h2>Recommended For You</h2>
            </div>
            <div class="slick-slider">
                <?php $__currentLoopData = $recommendedVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="boxImg">
                            <?php
                                if($video->continueWatches->first()){
                                    $v_time = round($video->continueWatches->first()->time);
                                }
                                else{
                                    $v_time = 0;
                                }
                            ?>
                            <img src="<?php echo e(asset($video->thumbnail)); ?>" data-href="<?php echo e(URL::to('/video', $video->id)); ?>"
                                 class="video-list clickable" />
                            
                            <div class="pt-3">
                               <!--  <div class="title">
                                    <div>
                                        <?php echo e($video->title); ?>

                                        <p class="float-right">
                                            <?php if(isset($video->views)): ?>
                                                <?php echo e(sizeof($video->views)); ?> Views
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div> -->
                                <div class="details mt-1">
                                    <div class="profile-pic">
                                        <img src="<?php echo e(asset('assets/front/images/dummy.jpg')); ?>" alt="">
                                    </div>
                                    <div class="video-details">
                                        <div><?php echo e($video->title); ?></div>
                                        <div class="channel">
                                            <a href="<?php echo e(route('channel.index', $video->user->id)); ?>" class="color-white">
                                                <span class="text-capitalize"><?php echo e($video->user->name); ?></span>
                                            </a>
                                        </div>
                                    </div>
                                    <p class="ml-auto">
                                        <?php if(isset($video->views)): ?>
                                        <?php echo e(sizeof($video->views)); ?> Views
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="videos-row row justify-content-md-center">
        <div class="col-lg-12">
            <div class="heading">
                <h2>Watch List</h2>
            </div>
            <div class="slick-slider">
                <?php $__currentLoopData = $watchlistVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="boxImg">
                            <?php
                                if($video->continueWatches->first()){
                                    $v_time = round($video->continueWatches->first()->time);
                                }
                                else{
                                    $v_time = 0;
                                }
                            ?>
                            <img src="<?php echo e(asset($video->thumbnail)); ?>" data-href="<?php echo e(URL::to('/video', $video->id)); ?>"
                                class="video-list clickable" />
                            
                            <div class="pt-3">
                                <div class="details mt-1">
                                    <div class="profile-pic">
                                        <img src="<?php echo e(asset('assets/front/images/dummy.jpg')); ?>" alt="">
                                    </div>
                                    <div class="video-details">
                                        <div><?php echo e($video->title); ?></div>
                                        <div class="channel">
                                            <a href="<?php echo e(route('channel.index', $video->user->id)); ?>" class="color-white">
                                                <span class="text-capitalize"><?php echo e($video->user->name); ?></span>
                                            </a>
                                        </div>
                                    </div>
                                    <p class="ml-auto">
                                        <?php if(isset($video->views)): ?>
                                        <?php echo e(sizeof($video->views)); ?> Views
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="videos-row row justify-content-md-center">
        <div class="col-lg-12">
            <div class="heading">
                <h2>Continue Watching</h2>
            </div>
            <div class="slick-slider">
            <?php $__currentLoopData = $contWatchesVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="boxImg">
                        <?php 
                            if($video->continueWatches->first()){
                                $v_time = round($video->continueWatches->first()->time);
                            }
                            else{
                                $v_time = 0;
                            }
                        ?>
                        <img src="<?php echo e(asset($video->thumbnail)); ?>" data-href="<?php echo e(URL::to('/video', $video->id)); ?>"
                            class="video-list clickable" />
                        
                        <div class="pt-3">
                            <div class="details mt-1">
                                <div class="profile-pic">
                                    <img src="<?php echo e(asset('assets/front/images/dummy.jpg')); ?>" alt="">
                                </div>
                                <div class="video-details">
                                    <div><?php echo e($video->title); ?></div>
                                    <div class="channel">
                                        <a href="<?php echo e(route('channel.index', $video->user->id)); ?>" class="color-white">
                                            <span class="text-capitalize"><?php echo e($video->user->name); ?></span>
                                        </a>
                                    </div>
                                </div>
                                <p class="ml-auto">
                                    <?php if(isset($video->views)): ?>
                                    <?php echo e(sizeof($video->views)); ?> Views
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>

    <div class="videos-row row justify-content-md-center">
        <div class="col-lg-12">
            <div class="heading"   style="text-de: 2px solid white">
                <h2>Trending</h2>
            </div>
            <div class="slick-slider" >
            <?php $__currentLoopData = $trendingVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div class="boxImg">
                        <?php 
                            if($video->record->continueWatches->first()){
                                $v_time = round($video->record->continueWatches->first()->time);
                            }
                            else{
                                $v_time = 0;
                            }
                        ?>
                        <img src="<?php echo e(asset($video->record->thumbnail)); ?>" data-href="<?php echo e(URL::to('/video', $video->record->id)); ?>"
                            class="video-list clickable" />
                        
                        <div class="pt-3">
                            <div class="details mt-1">
                                <div class="profile-pic">
                                    <img src="<?php echo e(asset('assets/front/images/dummy.jpg')); ?>" alt="">
                                </div>
                                <div class="video-details">
                                    <div><?php echo e($video->record->title); ?></div>
                                    <div class="channel">
                                        <a href="<?php echo e(route('channel.index', $video->record->user->id)); ?>" class="color-white">
                                            <span class="text-capitalize"><?php echo e($video->record->user->name); ?></span>
                                        </a>
                                    </div>
                                </div>
                                <p class="ml-auto">
                                    <?php if(isset($video->record->views)): ?>
                                    <?php echo e(sizeof($video->record->views)); ?> Views
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    $( function() {
        $('.slick-track').addClass('float-left');
    });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.front-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/front/index.blade.php ENDPATH**/ ?>