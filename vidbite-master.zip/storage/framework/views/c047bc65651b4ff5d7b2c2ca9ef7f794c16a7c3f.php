<?php $__env->startSection('title', 'Topics'); ?>
<?php $__env->startSection('content'); ?>
    <div class="dashboard-ecommerce">
        <div class="container-fluid dashboard-content ">
            <div class="heading">
                <h2>Topics</h2>
                <div class="d-flex justify-content-end">
                    <a href="<?php echo e(route('createTopic')); ?>" class="btn btn-warning mb-2">Add</a>
                </div>
            </div>
            <table id="example" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Category</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($topic->name); ?></td>
                            <td><?php echo e($topic->parent_category->name); ?></td>
                            <td>
                                <div class="d-flex">
                                    <div class="edit-button mr-4">
                                        <a href="<?php echo e(route('topicEdit', $topic->id)); ?>"
                                            class="btn btn-primary">EDIT</a>
                                    </div>
                                    <div class="delete-button mr-4">
                                        <!-- <a href="" class="btn btn-danger">DELETE</a> -->
                                        <form method="POST" action="<?php echo e(route('topicDelete', $topic->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button type="submit" class="btn btn-danger">DELETE</button>
                                        </form>
                                    </div>
                                    <div class="delete-button">
                                        <!-- <a href="" class="btn btn-danger">DELETE</a> -->
                                        <form method="POST" action="<?php echo e(route('make.category', $topic->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-primary">MAKE CATEGORY</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/vidbite-master/resources/views/admin/categories/topics.blade.php ENDPATH**/ ?>