<?php $__env->startSection("content"); ?>

<html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  </head>
  <style>
      body {font-family: Arial, Helvetica, sans-serif;}
      form {border: 3px solid #f1f1f1;}
      
      input[type=text], input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
      }
      
      .button2 {
        background-color: #cf9d3c;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
      }
      
      button:hover {
        opacity: 0.8;
      }
      
      .cancelbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
      }
      
      .imgcontainer {
        text-align: center;
        margin: 24px 0 12px 0;
      }
      
      img.avatar {
        width: 40%;
        border-radius: 50%;
      }
      
      .container {
        padding: 16px;
      }
      
      span.psw {
        float: right;
        padding-top: 16px;
      }
      .log_form .row{
        justify-content:center;
      }
      .log_form .psw {
      margin-left: 10px;
      }
      .container.jj {
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .regs .form-style-agile label{
    color: #CF9D3C;
    }
  </style>
  <body>
    <div class="container-fluid" style="margin-top: 50px">
      <div class="log_form">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
              <form class="form-group" method="POST" action="<?php echo e(route('myCaptcha.post')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="container" style="background-color:#f1f1f1">
                  <button type="submit" class="btn btn-primary"><a href="<?php echo e(route('create_user')); ?>" style="border-radius: 20px;text-decoration: none;font-size:10px;color:white;">Create Account</a></button>
                </div>
                <div class="imgcontainer panel-heading">
                  <h1>Login</h1>
                </div>
                <div class="wrapper">
                  <div class="container-fluid">
                    <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                      <label><b>Username</b></label>
                      <input id="email" type="text"  name="email" value="<?php echo e(old('email')); ?>">
                      <?php if($errors->has('email')): ?>
                        <span class="help-block">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    <div  class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                      <label for="password" class="col-md-4 control-label">Password</label>
                      <input id="password" type="password" class="form-control" name="password">
                      <?php if($errors->has('password')): ?>
                        <span class="help-block">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                      <?php endif; ?>
                    </div>
                    <div  class="form-group">
                      <div class="captcha">
                          <span><?php echo captcha_img(); ?></span>
                          <a class ="btn-refresh" style="color:black; text-decoration:none; cursor: pointer;">Click to change</a>
                      </div>
                          <input id="captcha" type="text" class="form-control" placeholder="Enter Captcha" name="captcha">
                          <?php if($errors->has('captcha')): ?>
                            <span class="help-block">
                              <strong><?php echo e($errors->first('captcha')); ?></strong>
                            </span>
                          <?php endif; ?>
                    </div>
                    <div class="container jj" style="background-color:#f1f1f1">
                      <button type="submit" class="col-md-offset-5 btn btn-primary demobutton">Submit</button>
                      <div class="psw" style="font-size: 16px;">Forgot <a href="#" style="color:red">password?</a>
                      </div>
                    </div>
                  </div> 
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>


  <script type="text/javascript">
    $(".btn-refresh").click(function(){
      $.ajax({
        type:'GET',
        url:'refresh_captcha',
        success:function(data){
            console.log(data);
            $(".captcha span").html(data.captcha);
        }
      });
    });
  </script>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>