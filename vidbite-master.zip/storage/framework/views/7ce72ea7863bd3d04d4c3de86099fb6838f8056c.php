<?php $__env->startSection("content"); ?>

<section class="gallery_video">
        <div class="gallery_slider">
            <div class="slider_background">
                <img src="<?php echo e(asset('/image/gallery_slider.png')); ?>" alt="gallery img">
            </div>
            <div class="gallery_title">
                <h3>Representative Images</h3>
            </div>
        </div>
        <div class="gallery_vid container">
            <div class="row">
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe iframe class="embed-responsive-item" src="https://www.youtube.com/embed/C7-diiGkJwM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">World Lion Day (Gujarati)</h4>          
                    </div>
                </div>   
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/w-VmFkO124o" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">World Lion Day (English)</h4>          
                    </div>
                </div>   
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Bq11bcOBNWM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">Gir Under the Monsoon Clouds (Gujarati)</h4>          
                    </div>
                </div>   
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/WR5NN1wi5u4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">Gir Under the Monsoon Clouds (English)</h4>          
                    </div>
                </div> 
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/meWddaftiW0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">Asiatic Lion Kingdom During Monsoon</h4>          
                    </div>
                </div> 
                <div class="col-md-4 col-lg-4 video_se">
                    <div class="card_content">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/9dnU5qlExy4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                    <div class="panel_body">
                        <h4 class="text-center">World Lion Day 2021 Drawing and Photography Result</h4>          
                    </div>
                </div> 
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>