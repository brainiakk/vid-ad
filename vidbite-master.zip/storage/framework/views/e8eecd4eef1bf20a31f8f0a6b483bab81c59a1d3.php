<?php $request = app('Illuminate\Http\Request'); ?>


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="/css/main.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluide">
        <div class="card">
            <div class="row">
                <div class="col-md-5">  
                    <div class="add_btn_primary"> 
                        <h1 class="page_title">Representative Permit-Charges</h1> 
                    </div>
                </div>
                <div class="col-md-5"></div>
            </div>
        </div>
    </div>
<div class="container-fluide">
    <div class="card">
        <div class="row">
            <div class="col-md-5">  
                <div class="add_btn_primary"> 
                    <a href="<?php echo e(route('admin.addcontact')); ?>" style="text-decoration: none;color:white;">ADD Contact</a> 
                </div>
            </div>
            <div class="col-md-5"></div>
        </div>
    </div>
</div>
<div class="col-md-12"><br></div>
<div class="container">
    <div class="card">
        <div class="row">
            <form action="">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Address</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Categories</th>
                            <th>Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->address); ?></td>
                            <td><?php echo e($item->phone); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.edit',$item->id)); ?>"  class="btn btn-primary btn_edit" data-toggle="tooltip" data-tooltip="Edit">
                                    <i class="fa fa-edit"></i>
                                </a>
                                
                                <a  href="<?php echo e(route('admin.delete',$item->id)); ?>" class="btn btn-danger btn_delete" data-toggle="tooltip" data-tooltip="Delete !">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>    
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>