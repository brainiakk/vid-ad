<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">



<body>
    <div class="container">
        <div class="inner-page-content">
            <div class="inner-block-title">
                Terms &amp; Conditions
            </div>
        </div>

        <ul class="inner-list">
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                The 'e-Permit' is for a visit to 'Gir Jungle Safari', 'GIZ Devalia Safari', 'Ambardi Safari Park' and 'Girnar Nature Safari' only.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                It is compulsory to carry the 'e-Permit' during reporting and entry time.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                For the entry in 'Gir Jungle Safari', 'GIZ Devalia Safari', 'Ambardi Safari Park' and 'Girnar Nature Safari'
                <ul>
                    <li>All the visitors should carry their original photo identity proof (Aadhar Card/PAN Card/Driving Licence/Voter ID Card). </li>
                    <li>All visitors should carry their Original Photo Identity Proof (Aadhar Card/ Driving Licence/ Voter ID Card).</li>

                    <li>For <b>FOREIGNER</b>, it is compulsory to keep the original passport as the photo identity proof with him/her.</li>
                </ul>
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                <b>Entry will not be permitted for the safari without original photo identity proof.</b>
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                <b>During the reporting time, the presence of each person is compulsory.</b>
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                One 'e-Permit' allows entry of a maximum of 6 adults + 1 child* (3-12 years) to visit 'Gir Jungle Safari', 'GIZ Devalia Safari', 'Ambardi Safari Park' and 'Girnar Nature Safari' within the selected time slot on a particular route only.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                For Gir Jungle Safari and Girnar Nature Safari, one person can get only one 'e-Permit' per slot per day.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                'GIZ Devalia Safari Park' remain closed every Wednesday.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                The e-Permit doesn't include the eco-guide charges (Rs 400/- only) and safari gypsy vehicle charges for Gir Jungle safari (Rs 2000/- only), GIZ Devalia Gypsy Safari (Rs 1600/- only), and Girnar Nature Safari (Rs 2000/- only) which need to be paid directly to the respective eco-guide and safari gypsy vehicle owner.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                The Forest Department's concerned authorities reserve the full rights to change the time slot timings as per the weather/seasonal conditions or due to sudden, unavoidable circumstances.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                'Gir Jungle Trail' and 'Girnar Nature Safari' can be booked only through the online booking system, and 'GIZ Devalia Gypsy Safari can be booked online as well as current booking if the permits are available.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                For Gir Jungle Trail, GIZ Devalia Gypsy Safari, 'Ambardi Safari Park' and Girnar Nature Safari, online booking opens three months before the date. It closes down two hours before the date.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                For the details of 'Refund System' for cancellation of e-Permit, please check the 'Refund Table' given below.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                If one does not receive an e-Permit despite the successful financial transaction due to technical errors, a refund will be done in 15-20 working days. For such issues, kindly send an email to gslcsgir@yahoo.com or call us on 02877-285621.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                Gir Jungle Trail, GIZ Devalia Gypsy Safari, 'Ambardi Safari Park' and Girnar Nature Safari visitors are requested to arrive at the respective reception centres (boarding point) 30 minutes before the scheduled time mentioned in the e-Permit.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                If the late reporting at the boarding point, e-Permit will get cancelled, and no refund can be claimed.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                The waitlist will be cleared only as per the cancellation.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                Camera fees details will be available locally at the respective reception centres (if applicable).
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                An eco-guide will accompany the visitors during the safari, and eco-guide allocation will be done randomly by the concerned authority.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                For the safari, each visitor's name, his/her identity card number and type of identity card should be mentioned during the online booking
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                No other person than the registered visitor is allowed in the safari vehicle.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                Bookings with incomplete or incorrect I.D. proof will be considered invalid.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                <ul>
                    <li>No Gir Jungle Trail, GIZ Devalia Gypsy Safari, 'Ambardi Safari Park' and Girnar Nature Safari will be permitted against such bookings. </li>
                    <li>No refund will be made for such cases.</li>
                </ul>
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                Safari route and other information on Gir Jungle Safari, GIZ Devalia Gypsy Safari, 'Ambardi Safari Park' and Girnar Nature Safari will be given based on permit numbers during the reporting time at the respective reception centre.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                All disputes and legal matters are subject to the jurisdiction of Junagadh district, Gujarat state only.
            </div>
            <div class="faq-details">
                <i class="fas fa-angle-double-right"></i>
                The services such as the issue of duplicate permits for lost/mutilated/torn permits and bulk booking for more than six people (for Gir Jungle Trail, GIZ Devalia Gypsy Safari and Girnar Nature Safari) will not be provided.
            </div>
        </ul>

        <div class="all-table pb-5">
        <div class="inner-block-main-title">
            Gir Jungle Safari <span>Time Table</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="  col-sm-8 col-xs-12">
                <table class="table-1" cellpadding="5">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Days
                            </th>
                            <th>Morning Timings
                            </th>
                            <th>Evening Timings
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td data-th=" Vehicle Type"><label> Mini Bus </label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday </label>
                            </td>
                            <td data-th=" Morning Timings"><label>7:30 AM To 11 AM </label>
                            </td>
                            <td data-th="Evening Timings"><label>3 PM To 5 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>7 AM To 7:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>3 PM To 3:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>8 AM To 8:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>4 PM To 4:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>9 AM To 9:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>5 PM To 5:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>10 AM To 10:55 AM</label>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: Devalia Safari Park remains closed on every wednesday. </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>


        <div class="inner-block-main-title">
            Devalia Safari Park <span>Time Table</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="  col-sm-8 col-xs-12">
                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Days
                            </th>
                            <th>Morning Timings
                            </th>
                            <th>Evening Timings
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td data-th=" Vehicle Type"><label> Mini Bus </label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday </label>
                            </td>
                            <td data-th=" Morning Timings"><label>7:30 AM To 11 AM </label>
                            </td>
                            <td data-th="Evening Timings"><label>3 PM To 5 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>7 AM To 7:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>3 PM To 3:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>8 AM To 8:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>4 PM To 4:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>9 AM To 9:55 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>5 PM To 5:55 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Safari Gypsy</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>10 AM To 10:55 AM</label>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: Devalia Safari Park remains closed on every wednesday. </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>



        <div class="inner-block-main-title">
            Girnar Nature Safari <span>Time Table</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="col-sm-8">
                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Season
                            </th>
                            <th>Days
                            </th>
                            <th>Morning Timings
                            </th>
                            <th>Evening Timings
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td data-th="Season"><label>Summer
                                    <br>
                                    (1<sup>st</sup> March To 15<sup>th</sup> June)</label>
                            </td>
                            <td data-th="Days"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>6:00 AM to 9:00 AM</label>
                            </td>
                            <td data-th=" Evening Timings"><label>4 PM to 7 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th="Season"><label>Winter
                                    <br>
                                    (16<sup>th</sup> October To 28<sup>th</sup>/29<sup>th</sup> February)</label>
                            </td>
                            <td data-th="Days"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>6:45 AM to 9:45 AM</label>
                            </td>
                            <td data-th=" Evening Timings"><label>3 PM to 6 PM</label>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="4" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: The Sanctuary remains closed from 16th June to 15th Oct every year.
                                    <br>
                                    Girnar Safari will remain closed during Girnar Parikrama and Mahashivratri Festival
                                    every year as per Hindu Calender Days.
                                </strong>
                            </td>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>


        <div class="inner-block-main-title">
            Ambardi Safari Park <span>Time Table</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="  col-sm-8 col-xs-12">
                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Particulars
                            </th>
                            <th>Morning Timings
                            </th>
                            <th>Evening Timings
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Bus <br>
                                    (Non-AC)</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>8 AM To 9 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>3 PM To 4 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Bus <br>
                                    (Non-AC)</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>9 AM To 10 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>4 PM To 5 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td data-th=" Vehicle Type"><label>Bus <br>
                                    (Non-AC)</label>
                            </td>
                            <td data-th="Particulars"><label>Monday To Sunday</label>
                            </td>
                            <td data-th=" Morning Timings"><label>10 AM To 11 AM</label>
                            </td>
                            <td data-th="Evening Timings"><label>5 PM To 6 PM</label>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: Ambardi Safari Park remains closed on every tuesday. </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>


        <div class="inner-block-main-title">
            Gir Jungle Safari <span>Gypsy Permit Charges</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="col-sm-8 col-xs-12">

                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type</th>
                            <th>Days
                            </th>
                            <th>Particulars
                            </th>
                            <th>Indian (In Rs.)
                            </th>
                            <th>Foreigner (In Rs.)
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblSrNo_0">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblParticulars_0">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblIndian_0">800</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblForeigner_0">5600</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblSrNo_1">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblParticulars_1">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblIndian_1">100</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblForeigner_1">1400</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblSrNo_2">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblParticulars_2">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblIndian_2">1000</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblForeigner_2">7000</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblSrNo_3">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblParticulars_3">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblIndian_3">125</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirJungleTrailCharges_lblForeigner_3">1750</span></label>
                            </td>
                        </tr>

                        <tr>


                            <td colspan="5" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: In one E-permit maximum 6 persons (plus one child between 3-12 years) are allowed.<br>

                                    * The permit doesn't include the Guide charge (Rs. 400 only) and Gypsy charge (Rs. 2000 only), which must be paid separatley to respective Guides and Gypsy vehicle owners.
                                </strong>

                            </td>

                        </tr>
                    </tbody>
                </table>






            </div>
        </div>



        <div class="inner-block-main-title">
            Devalia Safari Park <span>Permit Charges</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class=" col-sm-8 col-xs-12">

                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Days
                            </th>
                            <th>Indian (In Rs.)
                            </th>
                            <th>Foreigner (In Rs.)
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td data-th="Vehicle Type">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblVehicle_0">Mini Bus</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblParticulars_0">Monday-Friday</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblIndian_0">150</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblForeigner_0">2800</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td data-th="Vehicle Type">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblVehicle_1">Mini Bus</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblParticulars_1">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblIndian_1">190</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaBusPermitCharge_lblForeigner_1">3500</span></label>
                            </td>
                        </tr>

                    </tbody>
                </table>



            </div>


        </div><br>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="  col-sm-8 col-xs-12">


                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Days
                            </th>
                            <th>Particulars
                            </th>
                            <th>Indian (In Rs.)
                            </th>
                            <th>Foreigner (In Rs.)
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td data-th="Vehicle">
                                <label>
                                    Safari Gypsy</label>
                            </td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblSrNo_0">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblParticulars_0">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblIndian_0">800</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblForeigner_0">5600</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td data-th="Vehicle">
                                <label>
                                    Safari Gypsy</label>
                            </td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblSrNo_1">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblParticulars_1">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblIndian_1">100</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblForeigner_1">1400</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td data-th="Vehicle">
                                <label>
                                    Safari Gypsy</label>
                            </td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblSrNo_2">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblParticulars_2">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblIndian_2">1000</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblForeigner_2">7000</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td data-th="Vehicle">
                                <label>
                                    Safari Gypsy</label>
                            </td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblSrNo_3">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblParticulars_3">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblIndian_3">125</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptDevaliaGypsy_lblForeigner_3">1750</span></label>
                            </td>
                        </tr>

                        <tr>

                            <td colspan="5" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: In one E-permit maximum 6 persons (plus one child between 3-12 years) are allowed.

                                    <br>
                                    * The permit doesn't include the Guide charge (Rs. 400 only) and Gypsy charge (Rs. 1600 only), which must be paid seperately to respective Guides and Gypsy vehicle owners. </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>


            </div>
        </div>


        <div class="inner-block-main-title">
            Girnar Nature Safari <span>Permit Charges</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="  col-sm-8 col-xs-12">

                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type</th>
                            <th>Days
                            </th>
                            <th>Particulars
                            </th>
                            <th>Indian (In Rs.)
                            </th>
                            <th>Foreigner (In Rs.)
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblSrNo_0">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblParticulars_0">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblIndian_0">800</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblForeigner_0">5600</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblSrNo_1">Monday to Friday</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblParticulars_1">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblIndian_1">100</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblForeigner_1">1400</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblSrNo_2">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblParticulars_2">Up To 6 persons</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblIndian_2">1000</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblForeigner_2">7000</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td><label>Safari Gypsy</label></td>
                            <td data-th="Days">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblSrNo_3">Saturday/Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblParticulars_3">Extra Child</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblIndian_3">125</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptGirnarNatureSafariCharges_lblForeigner_3">1750</span></label>
                            </td>
                        </tr>

                        <tr>

                            <td colspan="5" style="color: #741500; font-size: 18px; text-align: justify;">
                                <strong>Note: In one E-permit maximum 6 persons (plus one child between 3-12 years) are allowed.<br>
                                    The Permit charges don't include eco-guide charges (INR 400/-) and safari gypsy charges (INR 2000/-), which must be paid separately to the respective eco-guide and safari gypsy owner.

                                </strong>
                            </td>
                        </tr>
                    </tbody>
                </table>


            </div>
        </div>


        <div class="inner-block-main-title">
            Ambardi Safari <span>Permit Charges</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class=" col-sm-8 col-xs-12">

                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Vehicle Type
                            </th>
                            <th>Particulars
                            </th>
                            <th>Indian (In Rs.)
                                <br>
                                1 Person
                            </th>
                            <th>Foreigner (In Rs.)
                                <br>
                                1 Person
                            </th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td data-th="Vehicle Type">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblVehicle_0">Bus</span>
                                    <br>
                                    (Non-AC)
                                </label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblParticulars_0">Monday-Friday</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblIndian_0">150</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblForeigner_0">2800</span></label>
                            </td>
                        </tr>

                        <tr>
                            <td data-th="Vehicle Type">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblVehicle_1">Bus</span>
                                    <br>
                                    (Non-AC)
                                </label>
                            </td>
                            <td data-th="Particulars">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblParticulars_1">Saturday-Sunday/ <br>Festival Days</span></label>
                            </td>
                            <td data-th="Indian (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblIndian_1">190</span></label>
                            </td>
                            <td data-th="Foreigner (In Rs.)">
                                <label>
                                    <span id="ContentPlaceHolder1_rptAmbardiBusCharges_lblForeigner_1">3500</span></label>
                            </td>
                        </tr>

                    </tbody>
                </table>



            </div>
        </div>


        <div class="inner-block-main-title">
            Cancellation rules and refund policy against <span>cancellations for the visitors</span>
        </div>
        <div class="row">
            <div class="col-sm-2">
            </div>
            <div class="col-sm-8 col-xs-12">
                <table class="table-1">
                    <thead>
                        <tr>
                            <th>Sr No
                            </th>
                            <th>Cancellation Period
                            </th>
                            <th>Refundable Amount
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td data-th="Sr No">1
                            </td>
                            <td data-th="Cancellation Period">Before 10 Days
                            </td>
                            <td data-th="Refundable Amount">75%
                            </td>
                        </tr>
                        <tr>
                            <td data-th="Sr No">2
                            </td>
                            <td data-th="Cancellation Period">Before 5 Days
                            </td>
                            <td data-th="Refundable Amount">50%
                            </td>
                        </tr>
                        <tr>
                            <td data-th="Sr No">3
                            </td>
                            <td data-th="Cancellation Period">Before 2 Days
                            </td>
                            <td data-th="Refundable Amount">25%
                            </td>
                        </tr>
                        <tr>
                            <td data-th="Sr No">3
                            </td>
                            <td data-th="Cancellation Period">Less than 2 Days
                            </td>
                            <td data-th="Refundable Amount">0% (No Refund)
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>


    </div>



</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>