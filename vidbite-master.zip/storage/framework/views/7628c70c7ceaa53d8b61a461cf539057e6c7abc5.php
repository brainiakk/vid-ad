<?php $__env->startSection("content"); ?>


<!DOCTYPE html>
<html lang="en">



<div class="inner-page-content">
        <div class="container   ">
         
            <ul class="inner-list">
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    The biodiversity of Gir boasts many attractions that are, if not more, on par with the Asiatic Lions. Sighting them is equally exciting. Following are a fraction of such sightings that will make your trip memorable.
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    Look out for an odd Leopard, the prince of the forests, moving stealthily across the riverine patches. The alarm calls of Spotted Deer or Langurs would help to narrow down the search.
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    If you happen to visit after mid-summer, you have a chance to invariably hear, and sight it if sought patiently, one of the most beautiful birds of our country, the Indian Pitta, which happens to be migratory to this region. Let your faculties be kept open and we promise it will be a treat to watch it.
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    Gir has rich bird diversity, especially the Birds of Prey. An occasional Crested Serpent Eagle, a Changeable Hawk Eagle, a Red Headed Vulture, a group of Indian Vultures soaring or a roosting Mottled Wood Owl in a hollow or a Brown Fish Owl in the dense foliage can make it a day for a Bird-watcher’s excursion.
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    A Sambar Stag with fully grown antlers or a shy Four-horned antelope are indelible sightings which will always be preserved in your reminiscence.
                </div>
                <div class="faq-details">
                    <i class="fas fa-angle-double-right"></i>
                    Paradise Flycatchers, though not uncommon, can easily be missed if one focuses only on Lions. It certainly is one of the top three birds of India in terms of beauty and agility. The enchanting zest it exhibits is purely angelic.
                </div>

                


            </ul>
        </div>
    </div>





</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>