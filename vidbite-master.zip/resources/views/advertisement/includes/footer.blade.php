<footer class="footer site-footer position-fixed text-center" style="bottom: 0; clear: both;">
    <span>{{ \Config::get('app.name') }}</span>
</footer>